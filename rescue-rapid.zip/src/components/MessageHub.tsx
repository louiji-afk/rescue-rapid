import { useEffect, useMemo, useRef, useState } from "react";
import { MessageCircle, Siren, X } from "lucide-react";
import { useRescue } from "@/lib/rescue-store";
import { PingIndicator } from "@/components/PingIndicator";

type Bubble = { id: string; from: "you" | "doctor"; text: string; at: number; receipt?: string };

export function GlobalHeader() {
  const { clinicTickets, message, sessionKey } = useRescue();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(false);

  const bubbles = useMemo<Bubble[]>(() => {
    const list: Bubble[] = [];
    [...clinicTickets].filter((t) => !t.bot).sort((a, b) => a.startedAt - b.startedAt).forEach((t) => {
      if (t.description.trim()) list.push({ id: t.id + "-u", from: "you", text: t.description, at: t.startedAt, receipt: t.readByDoctor ? "👁️‍🗨️ Doctor reading... / ဖတ်ရှုနေပါသည်" : "✓ Sent / ပေးပို့ပြီး" });
      if (t.advice.trim()) list.push({ id: t.id + "-d", from: "doctor", text: t.advice, at: t.startedAt + 1 });
      (t.chat ?? []).forEach((m, i) => list.push({ id: t.id + "-c" + i, from: m.from === "doctor" ? "doctor" : "you", text: m.text ?? "📷 Photo", at: m.at }));
    });
    if (message.trim()) list.push({ id: "sos", from: "you", text: "🚨 " + message, at: Date.now(), receipt: "✓ Sent / ပေးပို့ပြီး" });
    return list;
  }, [clinicTickets, message]);

  const adviceSig = clinicTickets.filter((t) => !t.bot).map((t) => t.id + ":" + t.advice + ":" + (t.chat ?? []).filter((m) => m.from === "doctor").length).join("|");
  const prevSig = useRef(adviceSig);
  useEffect(() => {
    if (adviceSig !== prevSig.current) {
      const grew = clinicTickets.some((t) => t.advice.trim() || (t.chat ?? []).some((m) => m.from === "doctor"));
      if (!open && grew) setUnread(true);
      prevSig.current = adviceSig;
    }
  }, [adviceSig, open, clinicTickets]);

  const toggle = () => { setOpen((o) => !o); setUnread(false); };

  return (
    <>
      <header className="mx-auto grid w-full max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 pt-4">
        <div className="flex min-w-0 items-center gap-2">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-destructive text-destructive-foreground">
            <Siren className="h-5 w-5" />
          </span>
          <span className="truncate text-lg font-extrabold uppercase">Rescue <span className="text-destructive">Rapid</span></span>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
        <PingIndicator />
        <button
          type="button"
          onClick={toggle}
          aria-label={unread ? "Open messages (new message)" : "Open messages"}
          className="relative flex shrink-0 items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2 text-sm font-black text-foreground hover:bg-surface-2"
        >
          <MessageCircle className="h-5 w-5" />
          <span className="hidden sm:inline">💬 Messages</span>
          {unread && (
            <span className="absolute -right-1 -top-1 flex h-3.5 w-3.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive opacity-75" />
              <span className="relative inline-flex h-3.5 w-3.5 rounded-full border-2 border-background bg-destructive" />
            </span>
          )}
        </button>
        </div>
      </header>
      {open && (
        <div className="fixed inset-0 z-50 flex justify-end bg-foreground/30" onClick={toggle}>
          <aside
            onClick={(e) => e.stopPropagation()}
            className="flex h-full w-full max-w-md flex-col border-l border-border bg-background shadow-2xl animate-in slide-in-from-right"
          >
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div><p className="text-base font-black">💬 Message History / စာတိုမှတ်တမ်း</p>{sessionKey && <p className="text-xs font-bold text-muted-foreground">Session / ကုဒ်: #{sessionKey}</p>}</div>
              <button type="button" onClick={toggle} aria-label="Close" className="rounded-md p-1 hover:bg-surface-2"><X className="h-5 w-5" /></button>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              {bubbles.length === 0 ? (
                <p className="text-center text-sm text-muted-foreground">No messages yet / စာတိုမရှိသေးပါ</p>
              ) : bubbles.map((b) => (
                <div key={b.id} className={b.from === "you" ? "flex justify-end" : "flex justify-start"}>
                  <div className={b.from === "you"
                    ? "max-w-[85%] rounded-xl rounded-br-sm bg-surface-2 px-3 py-2 text-sm font-semibold text-foreground"
                    : "max-w-[85%] rounded-xl rounded-bl-sm bg-clinic px-3 py-2 text-sm font-semibold text-clinic-contrast"}>
                    <p className="text-[10px] font-black uppercase opacity-80">{b.from === "you" ? "You / သင်" : "🩺 Doctor / ဆရာဝန်"}</p>
                    <p className="whitespace-pre-wrap break-words">{b.text}</p>
                    {b.receipt && <p className="mt-1 text-right text-[10px] font-bold text-muted-foreground">{b.receipt}</p>}
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-border p-4">
              <button type="button" onClick={toggle} className="w-full rounded-lg bg-slate px-4 py-3 text-base font-black text-slate-foreground">
                Close Inbox / ပြန်ပိတ်ရန်
              </button>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
