import { useRescue } from "@/lib/rescue-store";

function Badge({ ok, okText, badText }: { ok: boolean; okText: string; badText: string }) {
  return (
    <div
      className={
        ok
          ? "rounded-2xl border border-safe/70 bg-safe px-3 py-2 text-xs font-bold leading-snug text-safe-foreground sm:text-sm"
          : "rounded-2xl border border-slate/30 bg-muted px-3 py-2 text-xs font-bold leading-snug text-slate sm:text-sm"
      }
    >
      {ok ? okText : badText}
    </div>
  );
}

export function SecurityBadges() {
  const { perms } = useRescue();

  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
      <div className="rounded-2xl border border-warn bg-warn px-3 py-2 text-xs font-bold leading-snug text-warn-foreground sm:text-sm">
        ⚠️ Please turn off VPN / တည်နေရာအမှန်သိနိုင်ရန် VPN ကို ပိတ်ပေးပါ
      </div>
      <Badge
        ok={perms.location}
        okText="🟢 Location Connected / တည်နေရာရရှိပါသည်"
        badText="Location Needed/ဖွင့်ပါ"
      />
      <Badge
        ok={perms.camera}
        okText="🟢 Camera Active / ကင်မရာပွင့်နေပါသည်"
        badText="Camera Needed/ကင်မရာဖွင့်ပါ"
      />
      <Badge
        ok={perms.mic}
        okText="🟢 Mic Ready / မိုက်ခရိုဖုန်းအဆင်သင့်ရှိပါသည်"
        badText="Mic Needed/မိုက်ခရိုဖုန်းဖွင့်ပါ"
      />
    </div>
  );
}
