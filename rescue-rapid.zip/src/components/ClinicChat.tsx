import { useEffect, useMemo, useRef, useState } from "react";
import { useRescue, type ClinicTicket } from "@/lib/rescue-store";

type Side = "patient" | "doctor";
type Item = { key: string; from: Side; at: number; text?: string | undefined; photo?: string | undefined; audio?: string };

export function shrinkImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, 800 / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext("2d")?.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.7));
    };
    img.onerror = reject;
    img.src = url;
  });
}

// One Telegram-style timeline shared by patient (Room 3) and doctor (admin clinic desk).
// Drafts sync live: patient draft = ticket.description, doctor draft = ticket.advice.
export function ClinicChat({ ticket, me, onDraft }: { ticket: ClinicTicket; me: Side; onDraft?: (v: string) => void }) {
  const { addChatMessage, addVoiceClip, setClinicAdvice, setClinicDescription } = useRescue();
  const draft = me === "patient" ? ticket.description : ticket.advice;
  const otherDraft = me === "patient" ? ticket.advice : ticket.description;
  const setDraft = onDraft ?? ((v: string) => (me === "patient" ? setClinicDescription(v) : setClinicAdvice(ticket.id, v)));
  const fileRef = useRef<HTMLInputElement | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);
  const [recording, setRecording] = useState(false);
  const [micError, setMicError] = useState(false);

  const items = useMemo<Item[]>(() => {
    const list: Item[] = [
      ...(ticket?.photos ?? []).map((p, i) => ({ key: "p" + i, from: "patient" as Side, at: ticket.startedAt, photo: p })),
      ...(ticket?.chat ?? []).map((m, i) => ({ key: "c" + i, from: m.from, at: m.at, text: m.text, photo: m.photo })),
      ...(ticket?.voiceClips ?? []).map((v, i) => ({ key: "v" + i, from: v.from, at: v.at, audio: v?.url })),
    ];
    return list.sort((a, b) => a.at - b.at);
  }, [ticket.photos, ticket.chat, ticket.voiceClips, ticket.startedAt]);

  useEffect(() => { endRef.current?.scrollIntoView({ block: "nearest" }); }, [items.length, otherDraft]);

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    addChatMessage(ticket.id, { from: me, text });
    setDraft("");
  };

  const toggleRec = async () => {
    if (recording) { recRef.current?.stop(); recRef.current = null; setRecording(false); return; }
    setMicError(false);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(s);
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = () => {
        s.getTracks().forEach((t) => t.stop());
        const fr = new FileReader();
        fr.onload = () => addVoiceClip(ticket.id, me, String(fr.result));
        fr.readAsDataURL(new Blob(chunks, { type: rec.mimeType }));
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
    } catch { setMicError(true); }
  };

  const lastMine = [...items].reverse().find((i) => i.from === "patient");

  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-clinic/40 bg-background">
      <div className="flex max-h-[28rem] min-h-72 flex-col gap-2 overflow-y-auto bg-clinic-soft p-3" role="log" aria-live="polite">
        {items.length === 0 && !otherDraft && (
          <p className="m-auto text-center text-sm font-semibold text-muted-foreground">
            🤖 Welcome to Rescue Rapid Consultation. Please describe your symptoms or attach a photo.
          </p>
        )}
        {items.map((it) => {
          const mine = it.from === me;
          return (
            <div key={it.key} className={mine ? "max-w-[80%] self-end" : "max-w-[80%] self-start"}>
              <p className={"text-[11px] font-bold text-muted-foreground " + (mine ? "text-right" : "")}>
                {it.from === "doctor" ? "Doctor / ဆရာဝန်" : "Patient / လူနာ"}
              </p>
              <div className={mine
                ? "rounded-2xl rounded-br-sm bg-clinic px-3 py-2 text-sm font-semibold text-clinic-contrast"
                : "rounded-2xl rounded-bl-sm border border-border bg-background px-3 py-2 text-sm font-semibold text-foreground"}>
                {it.text && <p className="whitespace-pre-wrap break-words">{it.text}</p>}
                {it.photo && (
                  <a href={it.photo} target="_blank" rel="noreferrer">
                    <img src={it.photo} alt="Attached photo" className="max-h-48 rounded-lg object-cover" />
                  </a>
                )}
                {it.audio && <audio controls src={it.audio} className="h-10 max-w-60" />}
              </div>
              {me === "patient" && it === lastMine && (
                <p className="text-right text-[11px] font-bold text-muted-foreground">
                  {ticket.readByDoctor ? "👁️‍🗨️ Doctor reading... / ဖတ်ရှုနေပါသည်" : "✓ Sent / ပေးပို့ပြီး"}
                </p>
              )}
            </div>
          );
        })}
        {otherDraft && (
          <div className="max-w-[80%] self-start rounded-2xl rounded-bl-sm border border-dashed border-clinic/50 bg-background px-3 py-2 text-sm font-semibold text-muted-foreground">
            <span className="whitespace-pre-wrap">{otherDraft}</span><span className="animate-blink">▌</span>
          </div>
        )}
        <div ref={endRef} />
      </div>
      <div className="flex items-end gap-2 border-t border-border p-2">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) { try { addChatMessage(ticket.id, { from: me, photo: await shrinkImage(f) }); } catch { /* unreadable image */ } }
          }}
        />
        <button type="button" onClick={() => fileRef.current?.click()} aria-label="Attach Photo"
          className="h-11 shrink-0 rounded-lg border border-clinic/40 px-3 text-lg hover:bg-clinic-soft" title="📷 Attach Photo / ဓာတ်ပုံပေးပို့ရန်">📷</button>
        <button type="button" onClick={() => void toggleRec()} aria-label={recording ? "Stop and send voice" : "Record voice"}
          className={recording
            ? "h-11 shrink-0 rounded-lg bg-destructive px-3 text-sm font-black text-destructive-foreground animate-blink"
            : "h-11 shrink-0 rounded-lg border border-clinic/40 px-3 text-sm font-black text-clinic-foreground hover:bg-clinic-soft"}>
          {recording ? "⏹️" : "🎤 Voice"}
        </button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          rows={1}
          aria-label={me === "doctor" ? "Reply Patient" : "Message"}
          placeholder={me === "doctor" ? "Reply Patient…" : "Describe your symptoms… / ရောဂါလက္ခဏာများကို ရေးပါ…"}
          className="min-h-11 min-w-0 flex-1 resize-none rounded-lg border border-clinic/40 bg-background px-3 py-2.5 text-sm font-semibold text-foreground outline-none placeholder:text-muted-foreground focus:border-clinic"
        />
        <button type="button" onClick={send} className="h-11 shrink-0 rounded-lg bg-clinic px-4 text-sm font-black text-clinic-contrast">Send</button>
      </div>
      {micError && <p className="px-3 pb-2 text-xs font-bold text-rose-foreground">Microphone blocked / မိုက်ခရိုဖုန်း ခွင့်မပြုပါ</p>}
    </div>
  );
}
