import { useEffect, useRef } from "react";
import { Flashlight, Mic, MicOff, PhoneOff, Siren } from "lucide-react";
import { SecurityBadges } from "@/components/SecurityBadges";
import { ClinicView } from "@/components/ClinicView";
import { GlobalHeader } from "@/components/MessageHub";
import { Button } from "@/components/ui/button";
import { useRescue } from "@/lib/rescue-store";
import { LandmarkLine, SmsFallback } from "@/components/Resilience";

function PatientLandmark() {
  const { coords } = useRescue();
  if (!coords) return null;
  return <div className="mb-5"><LandmarkLine lat={coords.lat} lng={coords.lng} /></div>;
}

function TitleHeader() {
  return (
    <div className="flex items-center justify-center gap-3">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-destructive text-destructive-foreground">
        <Siren className="h-6 w-6" />
      </span>
      <h1 className="truncate text-2xl font-extrabold uppercase sm:text-3xl">
        Rescue <span className="text-destructive">Rapid</span>
      </h1>
    </div>
  );
}

function OnboardingCard() {
  return (
    <div className="mt-4 rounded-xl border border-border bg-glass p-4 shadow-lg backdrop-blur-[8px]">
      <p className="text-sm font-black text-foreground">About Us / ကျွန်ုပ်တို့အကြောင်း</p>
      <ul className="mt-2 list-disc space-y-1 pl-5 text-sm font-semibold text-foreground">
        <li>Completely free online medical access across Myanmar</li>
        <li>Instant medical aid with no sign-in or accounts required</li>
        <li>Live-streaming technology to accelerate emergency rescue</li>
      </ul>
    </div>
  );
}

function SubHeader() {
  return (
    <p className="mt-4 text-base font-semibold text-foreground">
      Required Safety Protocols / လိုက်နာရမည့် အရေးပေါ်စည်းကမ်းချက်များ
    </p>
  );
}

const FIRST_AID: Record<"chest" | "breathing" | "bleeding", string[]> = {
  chest: [
    "• Stop and rest. Sit comfortably and stay still / ရပ်ပြီး အနားယူပါ။ ငြိမ်ငြိမ်ထိုင်ပါ။",
    "• Stay calm and breathe slowly / စိတ်အေးအေးထားပြီး ဖြည်းဖြည်း အသက်ရှူပါ။",
  ],
  breathing: [
    "• Sit completely upright. Do not lie down / မတ်မတ်ထိုင်ပါ။ လှဲမအိပ်ပါနဲ့။",
    "• Loosen any tight clothing around the neck / အဝတ်အစားများကို လျှော့ပေးပါ။",
  ],
  bleeding: [
    "• Apply firm, direct pressure with a clean cloth / အဝတ်သန့်သန့်ဖြင့် ဖိထားပါ။",
    "• Elevate the bleeding limb above heart level / သွေးထွက်သည့်နေရာကို မြှောက်ထားပါ။",
  ],
};

export function UserInterface() {
  return (<><GlobalHeader /><UserBody /></>);
}

function UserBody() {
  const {
    callActive,
    startCall,
    endCall,
    stream,
    flashlightOn,
    toggleFlashlight,
    callerMuted,
    toggleCallerMute,
    flagBot,
    message,
    setMessage,
    incidents,
    toggleTriageTag,
    operatorStream,
    coolingDown,
    activeTicketId,
    startClinic,
    sosStatus,
    sosError,
  } = useRescue();
  const honeypot = (
    <input
      type="text"
      name="subscriber_email_field"
      tabIndex={-1}
      autoComplete="off"
      aria-hidden="true"
      style={{ display: "none" }}
      onChange={(e) => { if (e.target.value) flagBot(); }}
    />
  );
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const speakerRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (speakerRef.current) speakerRef.current.srcObject = operatorStream;
  }, [operatorStream, callActive]);
  // Gentle repeating "live channel" ping while the call is active.
  useEffect(() => {
    if (!callActive) return;
    let ctx: AudioContext | null = null;
    try { ctx = new AudioContext(); } catch { return; }
    const ping = () => {
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = 880;
      const t = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.06, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.4);
    };
    ping();
    const id = window.setInterval(ping, 2500);
    return () => { window.clearInterval(id); void ctx?.close(); };
  }, [callActive]);
  const activeIncident = incidents.find((incident) => incident.isOnline);

  useEffect(() => {
    if (videoRef.current) videoRef.current.srcObject = stream;
  }, [stream]);

  if (!callActive && activeTicketId) {
    return (
      <>
        {honeypot}
        <ClinicView />
      </>
    );
  }

  if (!callActive) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 py-8">
        {honeypot}
        <TitleHeader />
        <OnboardingCard />
        <SubHeader />
        <div className="mt-6">
          <SecurityBadges />
        </div>
        <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-2">
          <div className="gateway-tactile flex flex-col items-center gap-4 rounded-xl bg-destructive p-5 text-destructive-foreground">
            <p className="text-center text-sm font-black uppercase tracking-wide">🚨 ENTER EMERGENCY ROOM / အရေးပေါ်အခန်းသို့ဝင်ရန်</p>
            <button
              onClick={() => void startCall()}
              className="grid h-56 w-56 place-items-center rounded-full border-4 border-destructive-foreground/60 bg-destructive text-destructive-foreground animate-siren focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring sm:h-64 sm:w-64"
            >
              <span className="px-6 text-center">
                <span className="block text-2xl font-black uppercase leading-tight sm:text-3xl">TRIGGER SOS CALL NOW</span>
                <span className="mt-2 block text-sm font-bold sm:text-base">အရေးပေါ်အခန်း</span>
              </span>
            </button>
            <p className="max-w-sm text-center text-sm">
              Starts your camera, microphone and live location for rescue teams.
            </p>
          </div>
          <button
            type="button"
            onClick={startClinic}
            className="gateway-tactile flex flex-col items-center justify-center gap-4 rounded-xl border-2 border-emerald bg-emerald p-6 text-center text-emerald-foreground hover:bg-emerald/90"
          >
            
            <span className="text-5xl" aria-hidden="true">🩺</span>
            <span className="text-2xl font-black uppercase leading-tight">START TELEMEDICINE</span>
            <span className="text-base font-bold">🩺 GENERAL CONSULTATION / အထွေထွေကျန်းမာရေးအခန်းသို့ဝင်ရန်</span>
            <span className="text-sm font-semibold">Chat with a doctor about everyday health problems.</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6">
      {honeypot}
      <audio ref={speakerRef} autoPlay className="hidden" />
      {coolingDown ? (
        <div role="status" className="mb-2 rounded-md border border-warn bg-warn px-4 py-4 text-center text-sm font-black text-warn-foreground sm:text-base">
          System Cooling Down. Security check active / အလွန်အကျွံနှိပ်ခြင်းမှ ကာကွယ်ရန် စနစ်ခေတ္တဆိုင်းငံ့ထားပါသည်
        </div>
      ) : sosStatus === "sent" ? (
      <div role="status" className="mb-2 rounded-md border border-safe bg-safe px-4 py-4 text-center text-sm font-black text-safe-foreground sm:text-base">
        🟢 Live Audio & Video Connected
      </div>
      ) : null}
      {sosStatus !== "idle" && (
        <div role="status" aria-live="assertive" className={sosStatus === "sent"
          ? "mb-2 rounded-md border border-safe bg-safe px-4 py-3 text-center text-sm font-black text-safe-foreground sm:text-base"
          : sosStatus === "failed"
            ? "mb-2 rounded-md border border-rose bg-rose px-4 py-3 text-center text-sm font-black text-rose-foreground sm:text-base"
            : "mb-2 rounded-md border border-warn bg-warn px-4 py-3 text-center text-sm font-black text-warn-foreground sm:text-base animate-pulse"}>
          {sosStatus === "sent" ? "✅ SOS Sent to Dispatch!" : sosStatus === "failed" ? (sosError?.startsWith("Database connection timed out") ? `⚠️ ${sosError}` : `⚠️ SOS not delivered — ${sosError ?? "unknown error"} — use the SMS button below`) : "📡 Sending Emergency Request..."}
        </div>
      )}
      <div className="mb-5 flex justify-center">
        <span className="rounded-full border border-border bg-surface-2 px-3 py-1 text-xs font-bold text-muted-foreground">
          HD Audio & Video / ကွန်ရက်အခြေအနေ ကောင်းမွန်ပါသည်
        </span>
      </div>
      <SmsFallback tags={activeIncident?.triageTags ?? []} />
      <PatientLandmark />
      {activeIncident?.operatorViewing && (
        <div role="status" className="mb-5 rounded-md border border-safe/70 bg-safe px-4 py-4 text-center text-sm font-bold leading-relaxed text-safe-foreground sm:text-base">
          An Operator is looking at you right now. You are not alone. / အော်ပရေတာမှ သင့်ကို ကြည့်ရှုနေပါသည်။ သင်နဲ့အတူရှိ‌ေနပါတယ် အားတင်းထားပါ💪။
        </div>
      )}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {/* LEFT COLUMN */}
        <div className="flex flex-col gap-4">
          <p className="-mb-2 text-sm font-bold text-foreground">
            Choose your problem / သင်ကြုံတွေ့နေရတာကိုရွေးပါ
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 md:grid-cols-1 lg:grid-cols-3" aria-label="Quick medical triage">
            {([
              ["chest", "🫀", "Chest Pain/ရင်ဘတ်အောင့်"],
              ["breathing", "💨", "Can't Breathe/အသက်ရှုကျပ်"],
              ["bleeding", "🩸", "Heavy Bleeding/သွေးထွက်လွန်"],
            ] as const).map(([tag, icon, label]) => (
              <Button
                key={tag}
                type="button"
                variant="outline"
                aria-pressed={activeIncident?.triageTags.includes(tag) ?? false}
                onClick={() => toggleTriageTag(tag)}
                className={activeIncident?.triageTags.includes(tag)
                  ? "triage-tactile h-auto min-h-16 whitespace-normal border-rose bg-rose px-3 py-3 text-center font-bold leading-snug text-rose-foreground hover:bg-rose"
                  : "triage-tactile h-auto min-h-16 whitespace-normal border-border bg-surface-2 px-3 py-3 text-center font-bold leading-snug text-foreground hover:bg-accent"
                }
              >
                <span aria-hidden="true" className="text-xl">{icon}</span>
                <span className="min-w-0 break-words">{label}</span>
              </Button>
            ))}
          </div>
          <div role="status" className="rounded-md border border-warn bg-warn p-3 text-warn-foreground">
            <p className="text-xs font-black uppercase">First Aid / ရှေးဦးသူနာပြုစုခြင်း</p>
            <ul className="mt-2 space-y-1 text-sm font-bold leading-snug">
              {(activeIncident?.triageTags.length ?? 0) === 0 ? (
                <li>Stay calm. Take slow, steady breaths. Help is routing to you. / စိတ်အေးအေးထားပါ။ ဖြည်းဖြည်းချင်း အသက်ရှူပါ။ အကူအညီလာနေပါပြီ။</li>
              ) : (
                activeIncident!.triageTags.flatMap((tag) => FIRST_AID[tag].map((line) => <li key={tag + line}>{line}</li>))
              )}
            </ul>
          </div>
          <div className="panel p-3">
            <label
              htmlFor="emergency-message"
              className="text-xs font-black uppercase tracking-wide text-muted-foreground"
            >
              Emergency Message Box
            </label>
            <textarea
              id="emergency-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={7}
              placeholder="Type address or symptoms here if you cannot speak / စကားမပြောနိုင်ပါက ဤနေရာတွင် စာရေးသားအကြောင်းကြားပါ"
              className="mt-2 w-full resize-none rounded-lg border border-input bg-background px-3 py-3 text-base font-semibold text-foreground outline-none placeholder:text-muted-foreground focus:border-ring"
            />
          </div>
        </div>

        {/* RIGHT COLUMN */}
        <div className="flex flex-col gap-4">
          <div className="panel overflow-hidden">
            <div className="flex items-center justify-between px-3 py-2 text-xs font-black uppercase tracking-wide text-muted-foreground">
              <span>Camera Preview Box</span>
              <span className="text-safe-foreground animate-blink">● LIVE</span>
            </div>
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="aspect-video w-full bg-surface-2 object-cover"
            />
          </div>

          <div className="flex flex-col items-center gap-2 rounded-lg border border-border bg-surface p-3">
            <p role="status" className="text-center text-sm font-bold text-foreground">
              {callerMuted
                ? "🔴 You're muted, turn on your mic to speak / မိုက်ခရိုဖုန်းပိတ်ထားပါသည်၊ စကားပြောရန် ပြန်ဖွင့်ပါ"
                : "🟢 Your mic is on, can speak / မိုက်ခရိုဖုန်းပွင့်နေပါသည်၊ စကားပြောနိုင်ပါသည်"}
            </p>
            <button
              type="button"
              aria-pressed={!callerMuted}
              onClick={toggleCallerMute}
              className={callerMuted
                ? "grid h-20 w-20 place-items-center rounded-full border-2 border-rose bg-rose text-rose-foreground"
                : "grid h-20 w-20 place-items-center rounded-full border-2 border-safe bg-safe text-safe-foreground"}
              aria-label={callerMuted ? "Unmute microphone" : "Mute microphone"}
            >
              {callerMuted ? <MicOff className="h-9 w-9" /> : <Mic className="h-9 w-9" />}
            </button>
            <span className={callerMuted
              ? "rounded-md bg-rose px-2 py-1 text-xs font-black text-rose-foreground"
              : "rounded-md bg-safe px-2 py-1 text-xs font-black text-safe-foreground"}>
              {callerMuted ? "🔇 Muted" : "🎤 Mic Live"}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            <button
              onClick={toggleFlashlight}
              className={
                flashlightOn
                  ? "flex flex-col items-center gap-2 rounded-lg bg-warn px-3 py-5 text-sm font-black text-warn-foreground"
                  : "flex flex-col items-center gap-2 rounded-lg border border-warn/50 bg-warn/10 px-3 py-5 text-sm font-black text-warn-foreground"
              }
            >
              <Flashlight className="h-7 w-7" />
              <span className="text-center leading-tight">Flashlight / ဓာတ်မီး</span>
            </button>

          </div>

          <button
            onClick={endCall}
            className="flex w-full items-center justify-center gap-3 rounded-lg bg-destructive px-4 py-5 text-lg font-black uppercase text-destructive-foreground"
          >
            <PhoneOff className="h-6 w-6" />
            End Call / ဖုန်းချပါ
          </button>
        </div>
      </div>
      {flashlightOn && (
        <div className="pointer-events-none fixed inset-0 z-40 bg-warn/10 mix-blend-screen" />
      )}
    </div>
  );
}
