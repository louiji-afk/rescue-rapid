import { useEffect, useState } from "react";
import { useRescue } from "@/lib/rescue-store";

export function useOnline() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    setOnline(navigator.onLine);
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => { window.removeEventListener("online", up); window.removeEventListener("offline", down); };
  }, []);
  return online;
}

const TAG_TEXT = { chest: "Chest pain", breathing: "Can't breathe", bleeding: "Heavy bleeding" } as const;

/** Shown during SOS when the device loses internet: opens the phone's SMS app pre-filled. */
export function SmsFallback({ tags }: { tags: (keyof typeof TAG_TEXT)[] }) {
  const online = useOnline();
  const { coords, message } = useRescue();
  if (online) return null;
  const lines = [
    "SOS - Rescue Rapid emergency",
    tags.length ? "Problem: " + tags.map((t) => TAG_TEXT[t]).join(", ") : "",
    message.trim() ? "Message: " + message.trim().slice(0, 300) : "",
    coords ? `GPS: ${coords.lat.toFixed(5)},${coords.lng.toFixed(5)}` : "GPS: unavailable",
    coords ? `Map: https://maps.google.com/?q=${coords.lat.toFixed(5)},${coords.lng.toFixed(5)}` : "",
  ].filter(Boolean);
  const href = `sms:?&body=${encodeURIComponent(lines.join("\n"))}`;
  return (
    <div role="alert" className="mb-5 rounded-xl border-2 border-destructive bg-rose p-4 text-center">
      <p className="text-sm font-bold text-rose-foreground">Internet connection lost / အင်တာနက် ပြတ်တောက်နေပါသည်</p>
      <a href={href} className="mt-3 block rounded-xl bg-destructive px-4 py-5 text-xl font-black text-destructive-foreground sm:text-2xl">
        📶 No Internet? Send SOS via Direct SMS
      </a>
    </div>
  );
}

const geoCache = new Map<string, string>();

/** Reverse-geocodes coordinates via OpenStreetMap Nominatim (rounded, debounced, cached). */
export function useLandmark(lat?: number, lng?: number) {
  const key = lat != null && lng != null ? `${lat.toFixed(3)},${lng.toFixed(3)}` : "";
  const [name, setName] = useState<string | null>(key ? geoCache.get(key) ?? null : null);
  useEffect(() => {
    if (!key) { setName(null); return; }
    const hit = geoCache.get(key);
    if (hit) { setName(hit); return; }
    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      try {
        const [a, b] = key.split(",");
        const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=17&lat=${a}&lon=${b}&accept-language=en,my`, { signal: ctrl.signal });
        const j = (await r.json()) as { display_name?: string };
        if (j.display_name) { geoCache.set(key, j.display_name); setName(j.display_name); }
      } catch { /* offline or rate-limited */ }
    }, 1200);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [key]);
  return name;
}

export function LandmarkLine({ lat, lng }: { lat?: number | undefined; lng?: number | undefined }) {
  const name = useLandmark(lat, lng);
  if (lat == null || lng == null) return null;
  return (
    <p className="mt-2 rounded-lg bg-surface-2 p-3 text-sm font-bold text-foreground">
      📍 {name ?? "Finding nearest landmark… / နေရာရှာနေသည်…"}
    </p>
  );
}
