import { useEffect, useState } from "react";

export function PingIndicator() {
  const [ping, setPing] = useState(14);

  useEffect(() => {
    const timer = window.setInterval(() => setPing(12 + Math.floor(Math.random() * 7)), 3500);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <span title="Simulated network latency" className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap text-xs font-bold text-muted-foreground">
      <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-emerald" />
      ⚡ Ping: {ping}ms
    </span>
  );
}