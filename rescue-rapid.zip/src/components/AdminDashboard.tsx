import { ClinicChat } from "@/components/ClinicChat";
import { Component, useEffect, useRef, useState, type ReactNode } from "react";
import { MapPin, Mic, MicOff } from "lucide-react";
import { isUnverified, useRescue } from "@/lib/rescue-store";
import { CLINIC_SYMPTOMS } from "@/components/ClinicView";
import { PingIndicator } from "@/components/PingIndicator";
import { LandmarkLine } from "@/components/Resilience";

class ChatBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override componentDidCatch(e: unknown) { console.error("Clinic chat render error", e); }
  override render() {
    return this.state.failed
      ? <p className="rounded-md border border-warn bg-warn p-3 text-sm font-bold text-warn-foreground">Some messages could not be shown. / စာအချို့ကို ပြသ၍မရပါ။</p>
      : this.props.children;
  }
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="flex items-center gap-3 rounded-lg border border-border bg-surface-2 px-3 py-2 text-left text-xs font-bold text-muted-foreground"
    >
      <span
        className={
          checked
            ? "relative h-5 w-9 shrink-0 rounded-full bg-teal"
            : "relative h-5 w-9 shrink-0 rounded-full bg-muted"
        }
      >
        <span
          className={
            checked
              ? "absolute right-0.5 top-0.5 h-4 w-4 rounded-full bg-destructive-foreground transition-all"
              : "absolute left-0.5 top-0.5 h-4 w-4 rounded-full bg-foreground transition-all"
          }
        />
      </span>
      {label}
    </button>
  );
}

export function AdminDashboard() {
  const [env, setEnv] = useState<"emergency" | "clinic">("emergency");
  const {
    incidents,
    selectedId,
    selectIncident,
    deleteIncident,
    coords,
    stream,
    message,
    mockCoords,
    setMockCoords,
    voiceBridge,
    startVoiceBridge,
    stopVoiceBridge,
    callerAudioStream,
    callerAudioSimulated,
    clinicTickets,
    selectedTicketId,
    selectTicket,
    deleteTicket,
    addChatMessage,
  } = useRescue();
  const tickets = clinicTickets.filter((t) => !t.bot && t.type === "telemedicine");
  const ticket = tickets.find((t) => t.id === selectedTicketId) ?? null;
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const rank = (i: (typeof incidents)[number]) => (i.flooding ? 2 : isUnverified(i) ? 1 : 0);
  const queue = incidents.filter((i) => !i.bot && i.type === "emergency").sort((a, b) => rank(a) - rank(b));
  const selected = queue.find((i) => i.id === selectedId) ?? null;
  // Open the newest live incident by default so its camera, audio and location show immediately.
  const firstLiveId = queue.find((i) => i.isOnline)?.id;
  useEffect(() => {
    if (!selectedId && firstLiveId) selectIncident(firstLiveId);
  }, [selectedId, firstLiveId, selectIncident]);
  const seenIds = useRef<Set<string> | null>(null);
  const [ripplingIds, setRipplingIds] = useState<Set<string>>(() => new Set());
  const rippleTimers = useRef<Map<string, number>>(new Map());

  useEffect(() => () => { rippleTimers.current.forEach((timer) => window.clearTimeout(timer)); }, []);

  // Double-strike chime when a new incident card enters the queue.
  useEffect(() => {
    const ids = [...queue.map((i) => i.id), ...tickets.map((t) => t.id)];
    if (seenIds.current === null) {
      seenIds.current = new Set(ids);
      return;
    }
    const seen = seenIds.current;
    const freshIds = ids.filter((id) => !seen.has(id));
    ids.forEach((id) => seen.add(id));
    if (!freshIds.length) return;
    setRipplingIds((previous) => new Set([...previous, ...freshIds]));
    freshIds.forEach((id) => {
      const timer = window.setTimeout(() => {
        setRipplingIds((previous) => {
          const next = new Set(previous);
          next.delete(id);
          return next;
        });
        rippleTimers.current.delete(id);
      }, 3000);
      rippleTimers.current.set(id, timer);
    });
    try {
      const ctx = new AudioContext();
      [0, 0.28].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 1046;
        const t = ctx.currentTime + offset;
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.25, t + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.5);
      });
      setTimeout(() => void ctx.close(), 1200);
    } catch {
      /* audio unavailable */
    }
  }, [queue.length, tickets.length]);

  // Repeating high-priority siren until each new live incident is acknowledged.
  const [ackIds, setAckIds] = useState<Set<string>>(() => new Set());
  const ackLoaded = useRef(false);
  useEffect(() => {
    try { setAckIds(new Set(JSON.parse(localStorage.getItem("rr-acked") ?? "[]"))); } catch { /* noop */ }
    ackLoaded.current = true;
  }, []);
  const acknowledge = (id: string) => setAckIds((prev) => {
    const next = new Set(prev); next.add(id);
    try { localStorage.setItem("rr-acked", JSON.stringify([...next].slice(-200))); } catch { /* noop */ }
    return next;
  });
  const unacked = queue.filter((i) => i.isOnline && !ackIds.has(i.id)).length;
  useEffect(() => {
    if (!unacked) return;
    let ctx: AudioContext | null = null;
    const wail = () => {
      try {
        ctx ??= new AudioContext();
        void ctx.resume();
        const osc = ctx.createOscillator(); const gain = ctx.createGain();
        const t = ctx.currentTime;
        osc.type = "triangle";
        osc.frequency.setValueAtTime(700, t);
        osc.frequency.linearRampToValueAtTime(1300, t + 0.5);
        osc.frequency.linearRampToValueAtTime(700, t + 1);
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.22, t + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.05);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t); osc.stop(t + 1.1);
      } catch { /* audio blocked until the operator interacts */ }
    };
    wail();
    const iv = setInterval(wail, 1800);
    return () => { clearInterval(iv); setTimeout(() => void ctx?.close(), 1200); };
  }, [unacked]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.srcObject = selected ? stream : null;
    if (selected && stream) { v.muted = true; void v.play().catch(() => {}); }
  }, [stream, selected]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    el.srcObject = selected ? callerAudioStream : null;
    if (selected && callerAudioStream) void el.play().catch(() => {});
  }, [callerAudioStream, selected]);

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-xl font-black uppercase tracking-tight sm:text-2xl">
          Rescue Rapid — Command Desk
        </h2>
        <PingIndicator />
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2" role="tablist" aria-label="Admin environment">
        {([
          ["emergency", "🚨 Emergency Control Center"],
          ["clinic", "🩺 Outpatient Telemedicine Clinic"],
        ] as const).map(([key, label]) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={env === key}
            onClick={() => setEnv(key)}
            className={env === key
              ? (key === "emergency"
                ? "min-h-12 rounded-lg border-2 border-destructive bg-destructive px-3 py-2 text-xs font-black uppercase text-destructive-foreground sm:text-sm"
                : "min-h-12 rounded-lg border-2 border-clinic bg-clinic px-3 py-2 text-xs font-black uppercase text-clinic-contrast sm:text-sm")
              : "min-h-12 rounded-lg border border-border bg-surface-2 px-3 py-2 text-xs font-black uppercase text-muted-foreground sm:text-sm"}
          >
            {label}
          </button>
        ))}
      </div>

      <div className={env === "emergency" ? "mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3" : "mt-4 grid grid-cols-1 gap-4 lg:grid-cols-[1fr_2fr]"}>
        {/* Incident queue */}
        <section className="panel p-3">
          {env === "emergency" && (<>
          <h3 className="text-xs font-black uppercase tracking-wide text-muted-foreground">
            🚨 Emergency Alerts
          </h3>
          <div className="mt-3 flex flex-col gap-2">
            {queue.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No active alerts. Trigger SOS on the user interface tab.
              </p>
            )}
            {queue.map((incident) => (
              <div
                key={incident.id}
                onClick={() => selectIncident(incident.id)}
                className={
                  incident.id === selectedId
                     ? `cursor-pointer rounded-lg border border-teal bg-teal/20 p-3 ${ripplingIds.has(incident.id) ? "incoming-ripple" : ""}`
                     : `cursor-pointer rounded-lg border border-border bg-surface-2 p-3 ${ripplingIds.has(incident.id) ? "incoming-ripple" : ""}`
                }
              >
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-black">{incident.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(incident.startedAt).toLocaleTimeString()}
                    </p>
                    {Number.isFinite(incident.lat) && Number.isFinite(incident.lng) ? (
                      <div className="mt-2 rounded-md border border-teal bg-teal/10 px-2 py-1 text-xs font-bold text-foreground">
                        📍 Lat: {incident.lat!.toFixed(5)}, Lng: {incident.lng!.toFixed(5)}
                        <a href={`https://www.google.com/maps?q=${incident.lat},${incident.lng}`} target="_blank" rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()} className="ml-2 underline text-teal">View on Map</a>
                      </div>
                    ) : (
                      <p className="mt-2 text-xs font-bold text-muted-foreground">📍 GPS not shared</p>
                    )}
                    <p className="mt-1 text-xs font-semibold text-muted-foreground">🎥 Tap card to open live camera & audio</p>
                    {!ackIds.has(incident.id) && (
                      <button type="button" onClick={(e) => { e.stopPropagation(); acknowledge(incident.id); }}
                        className="mt-2 animate-pulse rounded-md bg-destructive px-3 py-2 text-xs font-black uppercase text-destructive-foreground">
                        🔔 Acknowledge Incident
                      </button>
                    )}
                  </div>
                  {confirmId === incident.id ? (
                    <div className="flex shrink-0 flex-col gap-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => {
                          deleteIncident(incident.id);
                          setConfirmId(null);
                        }}
                        className="rounded-md bg-destructive px-2 py-1 text-xs font-black text-destructive-foreground"
                      >
                        Confirm Resolve? / အတည်ပြုပါ
                      </button>
                      <button
                        onClick={() => setConfirmId(null)}
                        className="rounded-md border border-border bg-muted px-2 py-1 text-xs font-bold text-foreground"
                      >
                        Cancel / ပယ်ဖျက်ပါ
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setConfirmId(incident.id);
                      }}
                      className="shrink-0 rounded-md border border-rose/70 bg-rose px-2 py-1 text-xs font-bold text-rose-foreground"
                    >
                      ❌ Clear Alert
                    </button>
                  )}
                </div>
                {incident.flooding && (
                  <p className="mt-2 rounded-md border border-warn bg-warn px-2 py-1 text-xs font-black text-warn-foreground">
                    ⚠️ SUSPECTED FLOODING / ထပ်ခါတလဲလဲဖြစ်နေသည်
                  </p>
                )}
                {isUnverified(incident) && (
                  <p className="mt-2 rounded-md border border-border bg-muted px-2 py-1 text-xs font-black text-muted-foreground">
                    ❌ UNVERIFIED CALLED / အချက်အလက်မစုံလင်ပါ
                  </p>
                )}
                {!incident.isOnline && (
                  <p className="mt-2 rounded-md bg-warn px-2 py-1 text-xs font-black text-warn-foreground">
                    ⚠️ DISCONNECTED / လိုင်းကျသွားသည်
                  </p>
                )}
                 {incident.triageTags.length > 0 && (
                   <p className="mt-2 text-xs font-bold text-rose-foreground">Medical priority: {incident.triageTags.length} tag{incident.triageTags.length === 1 ? "" : "s"}</p>
                )}
              </div>
            ))}
          </div>
          </>)}
          {env === "clinic" && (<>
          <h3 className="text-xs font-black uppercase tracking-wide text-clinic-foreground">
            🩺 Outpatient Clinic Tickets
          </h3>
          <div className="mt-3 flex flex-col gap-2">
            {tickets.length === 0 && (
              <p className="text-sm text-muted-foreground">No clinic tickets yet.</p>
            )}
            {tickets.map((t) => (
              <div
                key={t.id}
                onClick={() => selectTicket(t.id)}
                className={t.id === selectedTicketId
                   ? `cursor-pointer rounded-lg border-2 border-clinic bg-clinic-soft p-3 ${ripplingIds.has(t.id) ? "incoming-ripple" : ""}`
                   : `cursor-pointer rounded-lg border border-clinic/40 bg-clinic-soft p-3 ${ripplingIds.has(t.id) ? "incoming-ripple" : ""}`}
              >
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-black text-clinic-foreground">Clinic Ticket / ဆေးခန်း</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(t.startedAt).toLocaleTimeString()} · {(t.symptoms ?? []).length} symptom{(t.symptoms ?? []).length === 1 ? "" : "s"}{t.open ? "" : " · left"}
                    </p>
                  </div>
                  {confirmId === t.id ? (
                    <div className="flex shrink-0 flex-col gap-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => { deleteTicket(t.id); setConfirmId(null); }}
                        className="rounded-md bg-destructive px-2 py-1 text-xs font-black text-destructive-foreground"
                      >
                        Confirm Resolve? / အတည်ပြုပါ
                      </button>
                      <button
                        onClick={() => setConfirmId(null)}
                        className="rounded-md border border-border bg-muted px-2 py-1 text-xs font-bold text-foreground"
                      >
                        Cancel / ပယ်ဖျက်ပါ
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={(e) => { e.stopPropagation(); setConfirmId(t.id); }}
                      className="shrink-0 rounded-md border border-rose/70 bg-rose px-2 py-1 text-xs font-bold text-rose-foreground"
                    >
                      ❌ Clear Alert
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
          </>)}
        </section>

        {/* Live location */}
        {env === "emergency" && (
        <section className="panel p-3">
          <h3 className="text-xs font-black uppercase tracking-wide text-muted-foreground">
            Live Location
          </h3>
          {selected && coords ? (
            <>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-surface-2 p-3">
                  <p className="text-xs text-muted-foreground">Latitude</p>
                  <p className="text-xl font-black">{coords.lat.toFixed(6)}</p>
                </div>
                <div className="rounded-lg bg-surface-2 p-3">
                  <p className="text-xs text-muted-foreground">Longitude</p>
                  <p className="text-xl font-black">{coords.lng.toFixed(6)}</p>
                </div>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Accuracy ≈ {coords.accuracy ? `${Math.round(coords.accuracy)} m` : "unknown"}
              </p>
              <LandmarkLine lat={coords.lat} lng={coords.lng} />
            </>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">
              Select an active alert to read coordinates.
            </p>
          )}
          {selected && coords ? (
            <LiveMap lat={coords.lat} lng={coords.lng} />
          ) : (
            <div className="mt-4 grid aspect-square w-full place-items-center rounded-lg border border-dashed border-border bg-surface-2 text-xs font-bold text-muted-foreground">
              Map appears when an alert is selected
            </div>
          )}
          <a
            href={
              selected && coords
                ? `https://www.google.com/maps/search/?api=1&query=${coords.lat},${coords.lng}`
                : "https://www.google.com/maps"
            }
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 flex items-center justify-center gap-2 rounded-lg bg-teal px-3 py-3 text-sm font-black uppercase text-teal-foreground"
          >
            <MapPin className="h-4 w-4" /> Open External Google Maps
          </a>
          {selected && coords && (
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${coords.lat},${coords.lng}&travelmode=driving`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-destructive px-3 py-3 text-sm font-black uppercase text-destructive-foreground"
            >
              🚑 Open Direct Google Maps Navigation
            </a>
          )}
        </section>
        )}

        {/* Diagnostics */}
        <section className="panel p-3">
          <h3 className="text-xs font-black uppercase tracking-wide text-muted-foreground">
            Live Diagnostic Center
          </h3>
          {env === "clinic" && ticket ? (
            <div className="mt-3 flex flex-col gap-3">
              <div className="flex flex-wrap items-center gap-2 rounded-lg border border-clinic/40 bg-clinic-soft p-3">
                <p className="text-xs font-black text-clinic-foreground">Active Patient Symptoms / ရွေးချယ်ထားသော လက္ခဏာများ - </p>
                <div className="flex flex-wrap gap-2">
                  {(ticket.symptoms ?? []).length === 0 ? (
                    <span className="text-sm text-muted-foreground">None selected yet</span>
                  ) : (
                    CLINIC_SYMPTOMS.filter(([k]) => (ticket.symptoms ?? []).includes(k)).map(([k, label]) => (
                      <span key={k} className="rounded-md bg-clinic px-2 py-1 text-xs font-black text-clinic-contrast">{label}</span>
                    ))
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {["💊 Please take rest and stay hydrated.", "🏥 Please visit nearest clinic for physical checkup."].map((m) => (
                  <button key={m} type="button" onClick={() => addChatMessage(ticket.id, { from: "doctor", text: m })}
                    className="rounded-full border border-clinic/40 bg-clinic-soft px-3 py-2 text-xs font-bold text-clinic-foreground hover:bg-accent">{m}</button>
                ))}
              </div>
              <ChatBoundary key={ticket.id}>
                <ClinicChat ticket={ticket} me="doctor" />
              </ChatBoundary>
            </div>
          ) : env === "clinic" || !selected ? (
            <div className="mt-3 flex min-h-64 items-center justify-center rounded-lg border border-dashed border-border bg-surface-2 p-6 text-center">
              <p className="text-sm font-black text-muted-foreground">
                No Active Incident Selected
                <br />
                အရေးပေါ်အချက်ပြမှု မရှိသေးပါ
              </p>
            </div>
          ) : (
            <>
          {selected.triageTags.length === 0 ? (
            <div className="mt-3 rounded-md border border-warn bg-warn p-3 text-warn-foreground" role="status">
              <p className="text-xs font-black uppercase">Medical Triage</p>
              <p className="mt-1 text-sm font-black">Emergency SOS (Unspecified)</p>
            </div>
          ) : (
            <div className="mt-3 rounded-md border border-rose bg-rose p-3 text-rose-foreground" role="status">
              <p className="text-xs font-black uppercase">High Priority · Medical Triage</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {selected.triageTags.map((tag) => (
                  <span key={tag} className="rounded-md border border-rose-foreground/30 px-2 py-1 text-sm font-black">
                    {tag === "chest" ? "🫀 Chest Pain/ရင်ဘတ်အောင့်" : tag === "breathing" ? "💨 Can't Breathe/အသက်ရှုကျပ်" : "🩸 Heavy Bleeding/သွေးထွက်လွန်"}
                  </span>
                ))}
              </div>
            </div>
          )}
          <div className="mt-3 rounded-lg border border-teal bg-surface-2 p-2">
             <p className="px-1 pb-2 text-xs font-black uppercase tracking-wide text-muted-foreground">Active Call Window {selected.isOnline && <span className="text-safe-foreground animate-blink">● LIVE</span>}</p>
            <audio ref={audioRef} autoPlay className="hidden" />
            <p className="px-1 pb-2 text-xs font-bold text-muted-foreground">
              {callerAudioStream
                ? callerAudioSimulated
                  ? "🔊 Caller audio: simulated monitor link (mic blocked)"
                  : "🔊 Caller audio: live microphone"
                : "🔇 Caller audio: muted / no signal"}
            </p>
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              controls
              className="aspect-video w-full rounded-md bg-background object-cover"
            />
            <button
              type="button"
              disabled={!selected.isOnline}
              aria-pressed={voiceBridge}
              onClick={() => (voiceBridge ? stopVoiceBridge() : void startVoiceBridge())}
              className={voiceBridge
                ? "mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-safe bg-safe px-4 py-4 text-sm font-black text-safe-foreground"
                : "mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-rose bg-rose px-4 py-4 text-sm font-black text-rose-foreground disabled:opacity-50"}
            >
              {voiceBridge ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              {voiceBridge ? "🎤 Doctor Mic On" : "🔇 Doctor Mic Muted"}
            </button>
          </div>
          <div className="mt-3">
            <p className="text-xs font-black uppercase text-muted-foreground">
              Typing Live Readout
            </p>
            <div className="mt-2 min-h-24 rounded-lg bg-surface-2 p-3 text-sm font-semibold">
              {message ? (
                <>
                  {message}
                  <span className="animate-blink">▌</span>
                </>
              ) : (
                <span className="text-muted-foreground">Waiting for caller to type…</span>
              )}
            </div>
          </div>
            </>
          )}
        </section>
      </div>

      <footer className="mt-6 flex flex-wrap items-center gap-3 border-t border-border pt-4">
        <span className="text-xs font-black uppercase tracking-wide text-muted-foreground">
          Presentation Overrides
        </span>
        <Toggle
          label="Inject Mock Hackathon Coordinates"
          checked={mockCoords}
          onChange={setMockCoords}
        />
      </footer>
    </div>
  );
}

function LiveMap({ lat, lng }: { lat: number; lng: number }) {
  // Round so the embedded map only reloads when the caller moves ~10 m.
  const la = lat.toFixed(4);
  const ln = lng.toFixed(4);
  const d = 0.006;
  const bbox = `${(+ln - d).toFixed(4)},${(+la - d).toFixed(4)},${(+ln + d).toFixed(4)},${(+la + d).toFixed(4)}`;
  const src = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${la},${ln}`;
  return (
    <div className="relative mt-4">
    <iframe
      title="Caller live location map"
      src={src}
      loading="lazy"
      className="aspect-square w-full rounded-lg border border-border"
    />
    <MapPin aria-hidden className="pointer-events-none absolute left-1/2 top-1/2 h-10 w-10 -translate-x-1/2 -translate-y-full fill-destructive text-destructive-foreground drop-shadow-lg" />
    </div>
  );
}
