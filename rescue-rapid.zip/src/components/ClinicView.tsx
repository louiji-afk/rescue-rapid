import { ClinicChat } from "@/components/ClinicChat";
import { useRef, useState } from "react";
import { useRescue, type ClinicSymptom } from "@/lib/rescue-store";
import { Button } from "@/components/ui/button";

export const CLINIC_SYMPTOMS: [ClinicSymptom, string][] = [
  ["fever", "🌡 Fever"],
  ["headache", "🤕 Headache"],
  ["cough", "😷 Cough"],
  ["rash", "💡 Skin Rash"],
  ["stomach", "🤢 Stomach Ache"],
  ["fatigue", "😴 Fatigue"],
];

const SEVERE = ["stroke", "heart attack", "choking", "bleeding"];

export function ClinicView() {
  const { clinicTickets, activeTicketId, toggleSymptom, setClinicDescription, exitClinic, startCall } = useRescue();
  const ticket = clinicTickets.find((t) => t.id === activeTicketId);
  const [alertOpen, setAlertOpen] = useState(false);
  const dismissedRef = useRef("");
  if (!ticket) return null;

  const onDescribe = (v: string) => {
    setClinicDescription(v);
    const lower = v.toLowerCase();
    const hit = SEVERE.find((k) => lower.includes(k));
    if (hit && dismissedRef.current !== hit) { dismissedRef.current = hit; setAlertOpen(true); }
  };

  const escalate = () => { setAlertOpen(false); exitClinic(); void startCall(); };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6">
      <div className="rounded-xl border border-clinic/40 bg-surface p-4 sm:p-6">
        <h2 className="text-xl font-black text-clinic-foreground sm:text-2xl">
          🩺 Outpatient Telemedicine Room / အထွေထွေကျန်းမာရေး ဆွေးနွေးတိုင်ပင်ခန်း
        </h2>
        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-[2fr_3fr]">
          <div className="flex flex-col gap-4">
            <p className="text-sm font-bold text-foreground">
              Select Symptoms / ရောဂါလက္ခဏာများ ရွေးချယ်ပါ
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {CLINIC_SYMPTOMS.map(([key, label]) => {
                const on = ticket.symptoms.includes(key);
                return (
                  <Button
                    key={key}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggleSymptom(key)}
                    className={on
                      ? "triage-tactile h-auto min-h-12 whitespace-normal rounded-full border border-clinic bg-clinic px-3 py-3 text-sm font-bold leading-snug text-clinic-contrast hover:bg-clinic"
                      : "triage-tactile h-auto min-h-12 whitespace-normal rounded-full border border-slate/30 bg-muted px-3 py-3 text-sm font-bold leading-snug text-slate hover:bg-accent"}
                  >
                    {label}
                  </Button>
                );
              })}
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <ClinicChat ticket={ticket} me="patient" onDraft={onDescribe} />
            <button
              type="button"
              onClick={exitClinic}
              className="w-full rounded-lg bg-slate px-4 py-4 text-base font-black text-slate-foreground"
            >
              Back to Home / ပင်မစာမျက်နှာသို့
            </button>
          </div>
        </div>
      </div>
      {alertOpen && (
        <div role="alertdialog" aria-modal="true" className="fixed inset-0 z-50 grid place-items-center bg-foreground/50 p-4">
          <div className="w-full max-w-md rounded-xl border-2 border-destructive bg-background p-5 shadow-2xl">
            <p className="text-lg font-black text-destructive">🚨 This sounds like an emergency / အရေးပေါ်အခြေအနေဖြစ်နိုင်ပါသည်</p>
            <p className="mt-2 text-sm font-semibold text-foreground">
              Please switch to the Emergency Room now for live help. / အကူအညီ ချက်ချင်းရရန် အရေးပေါ်အခန်းသို့ ပြောင်းပါ။
            </p>
            <button type="button" onClick={escalate} className="mt-4 w-full rounded-lg bg-destructive px-4 py-4 text-base font-black uppercase text-destructive-foreground animate-siren">
              Go to Emergency Room / အရေးပေါ်အခန်းသို့သွားရန်
            </button>
            <button type="button" onClick={() => setAlertOpen(false)} className="mt-2 w-full rounded-lg border border-border px-4 py-3 text-sm font-bold text-muted-foreground">
              Stay here / ဒီမှာပဲနေမည်
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
