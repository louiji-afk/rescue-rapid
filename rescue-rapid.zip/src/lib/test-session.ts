// Local-only test session for the demo admin bypass. No network calls involved.
const KEY = "sb-mock-auth-token";
const LEGACY_KEY = "rescue-test-session";

export function isTestAdminCredentials(id: string, pw: string) {
  const v = id.trim().toLowerCase();
  return (v === "admin" || v === "admin@rescuerapid.com") && pw === "rescue2026";
}

export function setTestAdminSession() {
  try {
    localStorage.setItem(KEY, JSON.stringify({ role: "admin", user: { id: "mock-admin", email: "admin@rescuerapid.com" }, mock: true, created_at: Date.now() }));
  } catch {
    /* storage unavailable */
  }
}

export function hasTestAdminSession(): boolean {
  try {
    const raw = localStorage.getItem(KEY) ?? localStorage.getItem(LEGACY_KEY);
    if (!raw) return false;
    return JSON.parse(raw)?.role === "admin";
  } catch {
    return false;
  }
}

export function clearTestAdminSession() {
  try {
    localStorage.removeItem(KEY);
    localStorage.removeItem(LEGACY_KEY);
  } catch {
    /* storage unavailable */
  }
}

// Rejects after `ms` so auth calls never hang the UI indefinitely.
export function withTimeout<T>(promise: PromiseLike<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("timeout")), ms);
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

export const AUTH_TIMEOUT_MS = 5000;
export const NETWORK_ERROR_MSG =
  "Network / Supabase Connection Error. Check your VPN or Lovable Cloud connection.";
