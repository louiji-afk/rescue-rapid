import { hasTestAdminSession } from "@/lib/test-session";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type Context,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  createIncident, updateIncident, getIncidentStatus, createTicket, updateTicket,
  sendPatientMessage, getTicketMessages, sendDoctorVoice,
} from "@/lib/patient-sync.functions";

export type Incident = {
  id: string;
  type: "emergency";
  label: string;
  startedAt: number;
  isOnline: boolean;
  operatorViewing: boolean;
  triageTags: TriageTag[];
  deviceId: string;
  flooding: boolean;
  bot: boolean;
  telemetryChecked: boolean;
  telemetry: { location: boolean; camera: boolean; mic: boolean };
  lat?: number | null;
  lng?: number | null;
};

export function isUnverified(i: Incident) {
  return i.telemetryChecked && !i.telemetry.location && !i.telemetry.camera && !i.telemetry.mic;
}

const RATE_WINDOW_MS = 3 * 60 * 1000;
const RATE_MAX = 2;

function deviceFingerprint() {
  if (typeof window === "undefined") return "server";
  const raw = [navigator.userAgent, navigator.language, screen.width, screen.height, screen.colorDepth,
    Intl.DateTimeFormat().resolvedOptions().timeZone, navigator.hardwareConcurrency ?? 0].join("|");
  let h = 5381;
  for (let i = 0; i < raw.length; i++) h = ((h << 5) + h + raw.charCodeAt(i)) >>> 0;
  return "dev-" + h.toString(16);
}

export type TriageTag = "chest" | "breathing" | "bleeding";
export type ClinicSymptom = "fever" | "headache" | "cough" | "rash" | "stomach" | "fatigue";
export type ChatMsg = { id?: string; from: "patient" | "doctor"; text?: string | undefined; photo?: string | undefined; at: number };
export type ClinicTicket = {
  id: string;
  type: "telemedicine";
  startedAt: number;
  symptoms: ClinicSymptom[];
  description: string;
  advice: string;
  photos: string[];
  voiceClips: { id?: string; from: "patient" | "doctor"; url: string; at: number }[];
  chat: ChatMsg[];
  readByDoctor: boolean;
  open: boolean;
  bot: boolean;
};

type PermState = {
  location: boolean;
  camera: boolean;
  mic: boolean;
};

type Coords = { lat: number; lng: number; accuracy?: number } | null;

type RescueContextValue = {
  callActive: boolean;
  perms: PermState;
  mockCoords: boolean;
  setMockCoords: (v: boolean) => void;
  message: string;
  setMessage: (v: string) => void;
  coords: Coords;
  incidents: Incident[];
  selectedId: string | null;
  selectIncident: (id: string) => void;
  toggleTriageTag: (tag: TriageTag) => void;
  deleteIncident: (id: string) => void;
  stream: MediaStream | null;
  flashlightOn: boolean;
  toggleFlashlight: () => void;
  recording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
  voiceClips: { id: string; url: string; at: number }[];
  startCall: () => Promise<void>;
  endCall: () => void;
  voiceBridge: boolean;
  operatorStream: MediaStream | null;
  startVoiceBridge: () => Promise<void>;
  stopVoiceBridge: () => void;
  callerMuted: boolean;
  callerAudioStream: MediaStream | null;
  callerAudioSimulated: boolean;
  toggleCallerMute: () => void;
  botBlocked: boolean;
  flagBot: () => void;
  coolingDown: boolean;
  sosStatus: "idle" | "sending" | "sent" | "failed";
  sosError: string | null;
  clinicTickets: ClinicTicket[];
  activeTicketId: string | null;
  selectedTicketId: string | null;
  startClinic: () => void;
  exitClinic: () => void;
  toggleSymptom: (s: ClinicSymptom) => void;
  setClinicDescription: (v: string) => void;
  setClinicAdvice: (id: string, v: string) => void;
  selectTicket: (id: string) => void;
  deleteTicket: (id: string) => void;
  addClinicPhoto: (url: string) => void;
  addVoiceClip: (id: string, from: "patient" | "doctor", url: string) => void;
  addChatMessage: (id: string, msg: Omit<ChatMsg, "at">) => void;
  sessionKey: string;
};

// A refresh can replace this module while an already-mounted provider is still
// rendering. Reuse the context object so refreshed consumers still see it.
const rescueContextHost = globalThis as typeof globalThis & {
  __rescueRapidContext?: Context<RescueContextValue | null>;
};
const RescueContext = rescueContextHost.__rescueRapidContext ??
  (rescueContextHost.__rescueRapidContext = createContext<RescueContextValue | null>(null));

export function RescueProvider({ children }: { children: ReactNode }) {
  const [callActive, setCallActive] = useState(false);
  const [perms, setPerms] = useState<PermState>({
    location: false,
    camera: false,
    mic: false,
  });
  const [mockCoords, setMockCoords] = useState(false);
  const [message, setMessage] = useState("");
  const [coords, setCoords] = useState<Coords>(null);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [recording, setRecording] = useState(false);
  const [voiceClips, setVoiceClips] = useState<{ id: string; url: string; at: number }[]>([]);

  const [voiceBridge, setVoiceBridge] = useState(false);
  const [callerMuted, setCallerMuted] = useState(false);
  const [botBlocked, setBotBlocked] = useState(false);
  const [callerAudioStream, setCallerAudioStream] = useState<MediaStream | null>(null);
  const [callerAudioSimulated, setCallerAudioSimulated] = useState(false);
  const [coolingDown, setCoolingDown] = useState(false);
  const [sosStatus, setSosStatus] = useState<"idle" | "sending" | "sent" | "failed">("idle");
  const [sosError, setSosError] = useState<string | null>(null);
  const [ownCall, setOwnCall] = useState(false);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [remoteOperator, setRemoteOperator] = useState<MediaStream | null>(null);
  const botRef = useRef(false);
  const [clinicTickets, setClinicTickets] = useState<ClinicTicket[]>([]);
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const activeTicketIdRef = useRef<string | null>(null);
  activeTicketIdRef.current = activeTicketId;
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [sessionKey, setSessionKey] = useState("");
  const restoredRef = useRef(false);
  // ---- Lovable Cloud sync -------------------------------------------------
  const tokenRef = useRef("");
  const sessionKeyRef = useRef("");
  sessionKeyRef.current = sessionKey;
  const [isStaff, setIsStaff] = useState(false);
  const isStaffRef = useRef(false);
  isStaffRef.current = isStaff;
  const ownIncidentRef = useRef<string | null>(null);
  const ownTicketsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    try {
      let t = localStorage.getItem("rr-patient-token") ?? "";
      if (t.length < 20) { t = crypto.randomUUID() + crypto.randomUUID(); localStorage.setItem("rr-patient-token", t); }
      tokenRef.current = t;
      ownTicketsRef.current = new Set(JSON.parse(localStorage.getItem("rr-own-tickets") ?? "[]"));
    } catch { tokenRef.current = crypto.randomUUID() + crypto.randomUUID(); }
  }, []);
  const rememberTicket = (id: string) => {
    ownTicketsRef.current.add(id);
    try { localStorage.setItem("rr-own-tickets", JSON.stringify([...ownTicketsRef.current])); } catch { /* noop */ }
  };
  const cloudSendMessage = (ticketId: string, id: string, from: "patient" | "doctor", raw: { text?: string | undefined; image?: string | undefined; audio?: string | undefined }) => {
    const body = Object.fromEntries(Object.entries(raw).filter(([, v]) => v)) as { text?: string; image?: string; audio?: string };
    if (from === "patient" && ownTicketsRef.current.has(ticketId) && tokenRef.current) {
      void sendPatientMessage({ data: { id, ticketId, token: tokenRef.current, ...body } }).catch(() => {});
    } else if (from === "doctor" && isStaffRef.current) {
      if (body.audio) {
        void sendDoctorVoice({ data: { id, ticketId, audio: body.audio } }).catch((e) => console.error("[voice]", e));
      } else {
        void supabase.from("chat_messages").insert({ id, ticket_id: ticketId, sender: "doctor", message_text: body.text ?? null, image_url: body.image ?? null }).then(() => {});
      }
    }
  };
  // Anonymous 6-digit session key + restore of chat/clinic state after refresh.
  useEffect(() => {
    let key = "";
    try {
      key = localStorage.getItem("rr-session-key") ?? "";
      if (!/^\d{6}$/.test(key)) {
        key = String(Math.floor(100000 + Math.random() * 900000));
        localStorage.setItem("rr-session-key", key);
      }
      const saved = JSON.parse(localStorage.getItem("rr-session-" + key) ?? "null");
      if (saved?.clinicTickets) {
        setClinicTickets((saved.clinicTickets as ClinicTicket[]).map((t) => ({ ...t, photos: t.photos ?? [], voiceClips: t.voiceClips ?? [], chat: t.chat ?? [], readByDoctor: !!t.readByDoctor })));
        setActiveTicketId(saved.activeTicketId ?? null);
      }
    } catch { /* storage unavailable */ }
    setSessionKey(key);
    restoredRef.current = true;
  }, []);
  useEffect(() => {
    if (!restoredRef.current || !sessionKey) return;
    try {
      localStorage.setItem("rr-session-" + sessionKey, JSON.stringify({ clinicTickets, activeTicketId }));
    } catch { /* quota exceeded (large photos) */ }
  }, [clinicTickets, activeTicketId, sessionKey]);
  // Cross-window live sync (patient "/" <-> admin "/admin") over BroadcastChannel.
  const chanRef = useRef<BroadcastChannel | null>(null);
  const lastSyncRef = useRef("");
  const snapRef = useRef<unknown>(null);
  const shared = { incidents, message, coords, mockCoords, perms, callActive, clinicTickets, callerMuted, voiceBridge };
  snapRef.current = shared;
  useEffect(() => {
    if (typeof BroadcastChannel === "undefined") return;
    const ch = new BroadcastChannel("rescue-rapid-sync");
    chanRef.current = ch;
    ch.onmessage = (e) => {
      const d = e.data as { type: string; state?: typeof shared };
      if (d.type === "hello") { ch.postMessage({ type: "state", state: snapRef.current }); return; }
      if (d.type !== "state" || !d.state) return;
      const s = d.state;
      lastSyncRef.current = JSON.stringify(s);
      setIncidents(s.incidents); setMessage(s.message); setCoords(s.coords);
      setMockCoords(s.mockCoords); setPerms(s.perms); setCallActive(s.callActive);
      setClinicTickets(((s.clinicTickets ?? []) as ClinicTicket[]).map((t) => ({ ...t, symptoms: t.symptoms ?? [], photos: t.photos ?? [], voiceClips: t.voiceClips ?? [], chat: t.chat ?? [] })));
      setCallerMuted(!!s.callerMuted); setVoiceBridge(!!s.voiceBridge);
    };
    ch.postMessage({ type: "hello" });
    return () => { ch.close(); chanRef.current = null; };
  }, []);
  useEffect(() => {
    const json = JSON.stringify(shared);
    if (json === lastSyncRef.current) return;
    lastSyncRef.current = json;
    try { chanRef.current?.postMessage({ type: "state", state: shared }); } catch { /* noop */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incidents, message, coords, mockCoords, perms, callActive, clinicTickets, callerMuted, voiceBridge]);
  const startClinic = useCallback(() => {
    const id = crypto.randomUUID();
    setClinicTickets((prev) => [{ id, type: "telemedicine" as const, startedAt: Date.now(), symptoms: [], description: "", advice: "", photos: [], voiceClips: [], chat: [], readByDoctor: false, open: true, bot: botRef.current }, ...prev]);
    setActiveTicketId(id);
    if (!botRef.current && tokenRef.current) {
      rememberTicket(id);
      void createTicket({ data: { id, token: tokenRef.current, sessionKey: sessionKeyRef.current } }).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const exitClinic = useCallback(() => {
    setActiveTicketId((cur) => {
      if (cur) setClinicTickets((prev) => prev.map((t) => (t.id === cur ? { ...t, open: false } : t)));
      return null;
    });
  }, []);
  const patchActive = useCallback((fn: (t: ClinicTicket) => ClinicTicket) => {
    const cur = activeTicketIdRef.current;
    if (cur) setClinicTickets((prev) => prev.map((t) => (t.id === cur ? fn(t) : t)));
  }, []);
  const toggleSymptom = useCallback((sym: ClinicSymptom) => patchActive((t) => ({
    ...t, symptoms: t.symptoms.includes(sym) ? t.symptoms.filter((x) => x !== sym) : [...t.symptoms, sym],
  })), [patchActive]);
  const setClinicDescription = useCallback((v: string) => patchActive((t) => ({ ...t, description: v })), [patchActive]);
  const addClinicPhoto = useCallback((url: string) => patchActive((t) => ({ ...t, photos: [...t.photos, url] })), [patchActive]);
  const addVoiceClip = useCallback((id: string, from: "patient" | "doctor", url: string) => {
    const mid = crypto.randomUUID();
    setClinicTickets((prev) => prev.map((t) => (t.id === id ? { ...t, voiceClips: [...t.voiceClips, { id: mid, from, url, at: Date.now() }] } : t)));
    cloudSendMessage(id, mid, from, { audio: url });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const addChatMessage = useCallback((id: string, msg: Omit<ChatMsg, "at">) => {
    const mid = crypto.randomUUID();
    setClinicTickets((prev) => prev.map((t) => (t.id === id ? { ...t, chat: [...t.chat, { ...msg, id: mid, at: Date.now() }] } : t)));
    cloudSendMessage(id, mid, msg.from, { text: msg.text, image: msg.photo });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const setClinicAdvice = useCallback((id: string, v: string) => {
    setClinicTickets((prev) => prev.map((t) => (t.id === id ? { ...t, advice: v } : t)));
  }, []);
  const selectTicket = useCallback((id: string) => {
    setSelectedTicketId(id); setSelectedId(null);
    setClinicTickets((prev) => prev.map((t) => (t.id === id ? { ...t, readByDoctor: true } : t)));
  }, []);
  const deleteTicket = useCallback((id: string) => {
    setClinicTickets((prev) => prev.filter((t) => t.id !== id));
    setSelectedTicketId((cur) => (cur === id ? null : cur));
    setActiveTicketId((cur) => (cur === id ? null : cur));
    if (isStaffRef.current) void supabase.from("outpatient_tickets").delete().eq("id", id).then(() => {});
  }, []);
  const streamRef = useRef<MediaStream | null>(null);
  useEffect(() => { streamRef.current = stream; }, [stream]);
  const flagBot = useCallback(() => {
    botRef.current = true;
    setBotBlocked(true);
    // Silently suppress outgoing media and drop the session from the admin queue.
    streamRef.current?.getTracks().forEach((t) => t.stop());
    setStream(null);
    setIncidents((prev) => prev.map((i) => (i.isOnline ? { ...i, bot: true } : i)));
    setClinicTickets((prev) => prev.map((t) => (t.open ? { ...t, bot: true } : t)));
  }, []);
  const [operatorStream, setOperatorStream] = useState<MediaStream | null>(null);
  const operatorStreamRef = useRef<MediaStream | null>(null);

  const stopVoiceBridge = useCallback(() => {
    operatorStreamRef.current?.getTracks().forEach((t) => t.stop());
    operatorStreamRef.current = null;
    setOperatorStream(null);
    setVoiceBridge(false);
  }, []);

  const startVoiceBridge = useCallback(async () => {
    // Simulated WebRTC session: operator mic is routed straight to the caller's speaker.
    try {
      const media = await navigator.mediaDevices.getUserMedia({ audio: true });
      operatorStreamRef.current = media;
      setOperatorStream(media);
    } catch {
      setOperatorStream(null);
    }
    setVoiceBridge(true);
  }, []);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const watchRef = useRef<number | null>(null);
  const discardClipsRef = useRef(false);

  // Real geolocation watch
  useEffect(() => {
    if (!callActive || mockCoords || typeof navigator === "undefined" || !navigator.geolocation) {
      return;
    }
    const id = navigator.geolocation.watchPosition(
      (pos) => {
        setPerms((p) => ({ ...p, location: true }));
        setCoords({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        });
      },
      () => setPerms((p) => ({ ...p, location: false })),
      { enableHighAccuracy: true, maximumAge: 0 },
    );
    watchRef.current = id;
    return () => {
      navigator.geolocation.clearWatch(id);
      watchRef.current = null;
    };
  }, [callActive, mockCoords]);

  // Mock hackathon coordinates: dynamic movement around Yangon
  useEffect(() => {
    if (!mockCoords) return;
    let t = 0;
    setPerms((p) => ({ ...p, location: true }));
    const iv = setInterval(() => {
      t += 1;
      setCoords({
        lat: 37.8199 + Math.sin(t / 9) * 0.0042,
        lng: -122.4783 + Math.cos(t / 11) * 0.0045,
        accuracy: 8,
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [mockCoords]);

  const stopTracks = useCallback((s: MediaStream | null) => {
    s?.getTracks().forEach((track) => track.stop());
  }, []);

  const startCall = useCallback(async () => {
    const deviceId = deviceFingerprint();
    const now = Date.now();
    const key = "rr-sos-presses-" + deviceId;
    let presses: number[] = [];
    try { presses = JSON.parse(sessionStorage.getItem(key) ?? "[]"); } catch { presses = []; }
    presses = presses.filter((t) => now - t < RATE_WINDOW_MS);
    presses.push(now);
    try { sessionStorage.setItem(key, JSON.stringify(presses)); } catch { /* noop */ }
    const flooding = presses.length > RATE_MAX;
    setCoolingDown(flooding);
    const isBot = botRef.current;
    setCallActive(true);
    setOwnCall(true);
    const id = crypto.randomUUID();
    if (!isBot && tokenRef.current) {
      ownIncidentRef.current = id;
      const tok = tokenRef.current;
      const sk = sessionKeyRef.current;
      setSosStatus("sending"); setSosError(null);
      void (async () => {
        // Wait (max 3s) for GPS or a cached fix so the alert carries a location.
        const loc = await new Promise<{ lat: number; lng: number } | null>((resolve) => {
          if (!navigator.geolocation) return resolve(null);
          const timer = setTimeout(() => resolve(null), 3000);
          navigator.geolocation.getCurrentPosition(
            (position) => { clearTimeout(timer); resolve({ lat: position.coords.latitude, lng: position.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { enableHighAccuracy: true, maximumAge: 60_000, timeout: 3000 },
          );
        });
        const payload = { id, token: tok, sessionKey: sk, type: "emergency" as const, latitude: loc?.lat ?? null, longitude: loc?.lng ?? null };
        // Primary: public SECURITY DEFINER RPC via REST. Backup: server function. "sent" only on 2xx.
        const anonKey = import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"] as string;
        const rpcBody = { p_id: id, p_token: tok, p_session_key: sk, p_latitude: payload.latitude, p_longitude: payload.longitude };
        let errMsg = "";
        const sbUrl = import.meta.env["VITE_SUPABASE_URL"] as string | undefined;
        if (!sbUrl || !anonKey) {
          errMsg = "Supabase Insert Error: missing VITE_SUPABASE_URL or VITE_SUPABASE_PUBLISHABLE_KEY";
        } else {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 4000);
          try {
            const r = await fetch(`${sbUrl}/rest/v1/rpc/trigger_emergency_sos`, {
              method: "POST",
              headers: { "Content-Type": "application/json", apikey: anonKey },
              body: JSON.stringify(rpcBody),
              signal: ctrl.signal,
            });
            const text = await r.text().catch(() => "");
            console.info("SOS RPC response", { status: r.status, statusText: r.statusText, body: text, payload: rpcBody });
            if (r.status === 200 || r.status === 201 || r.status === 204) {
              setSosError(null); setSosStatus("sent"); toast.success(`SOS RPC: ${r.status} OK`); return;
            }
            errMsg = `Supabase Insert Error: HTTP ${r.status} ${r.statusText} ${text}`.trim();
          } catch (e) {
            const m = e instanceof Error ? e.message : String(e);
            const timedOut = ctrl.signal.aborted || /failed to fetch|timed?\s?out|networkerror|load failed/i.test(m);
            errMsg = timedOut
              ? "Database connection timed out. Please check your network or VPN."
              : `Supabase Insert Error: ${m}`;
          } finally {
            clearTimeout(timer);
          }
        }
        console.error(errMsg);
        setSosError(errMsg); setSosStatus("failed");
        try { window.alert("SUPABASE ERROR: " + JSON.stringify(errMsg)); } catch { /* ignore */ }
      })();
    }
    setIncidents((prev) => [
      { id, type: "emergency" as const, label: "Distress Alert / အရေးပေါ်ဖုန်း", startedAt: now, isOnline: true, operatorViewing: false, triageTags: [],
        deviceId, flooding, bot: isBot, telemetryChecked: false, telemetry: { location: false, camera: false, mic: false } },
      ...prev.map((i) => (i.deviceId === deviceId && flooding ? { ...i, flooding: true } : i)),
    ]);
    if (!isBot) setSelectedId(id);
    if (isBot) return;
    try {
      const media = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } },
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      // Prioritise voice: let video degrade resolution before dropping audio quality.
      media.getVideoTracks().forEach((t) => { try { (t as MediaStreamTrack & { contentHint: string }).contentHint = "motion"; } catch { /* noop */ } });
      media.getAudioTracks().forEach((t) => { try { (t as MediaStreamTrack & { contentHint: string }).contentHint = "speech"; } catch { /* noop */ } });
      setCallerMuted(false);
      setStream(media);
      setPerms((p) => ({
        ...p,
        camera: media.getVideoTracks().length > 0,
        mic: media.getAudioTracks().length > 0,
      }));
    } catch {
      setPerms((p) => ({ ...p, camera: false, mic: false }));
    }
    setIncidents((prev) => prev.map((i) => (i.id === id ? { ...i, telemetryChecked: true } : i)));
  }, []);

  // Record telemetry packets received for the live incident.
  useEffect(() => {
    if (!callActive) return;
    setIncidents((prev) => prev.map((i) => {
      if (!i.isOnline) return i;
      const t = { location: i.telemetry.location || perms.location, camera: i.telemetry.camera || perms.camera, mic: i.telemetry.mic || perms.mic };
      return t.location === i.telemetry.location && t.camera === i.telemetry.camera && t.mic === i.telemetry.mic ? i : { ...i, telemetry: t };
    }));
  }, [callActive, perms]);

  const endCall = useCallback(() => {
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
    recorderRef.current = null;
    setRecording(false);
    setFlashlightOn(false);
    stopTracks(stream);
    setStream(null);
    setCallActive(false);
    setOwnCall(false);
    stopVoiceBridge();
    setPerms({ location: false, camera: false, mic: false });
    setIncidents((prev) => prev.map((i) => (i.id === selectedId ? { ...i, isOnline: false, operatorViewing: false } : i)));
    const ownId = ownIncidentRef.current;
    if (ownId && tokenRef.current) void updateIncident({ data: { id: ownId, token: tokenRef.current, is_online: false } }).catch(() => {});
    ownIncidentRef.current = null;
  }, [selectedId, stopTracks, stream, stopVoiceBridge]);

  // Unified caller audio link: real mic track, or a simulated monitor tone when the mic is blocked.
  useEffect(() => {
    if (!callActive || !ownCall) {
      setCallerAudioStream(null);
      setCallerAudioSimulated(false);
      return;
    }
    const realTracks = stream?.getAudioTracks() ?? [];
    if (realTracks.length > 0) {
      setCallerAudioStream(new MediaStream(realTracks));
      setCallerAudioSimulated(false);
      return;
    }
    if (callerMuted || typeof window === "undefined") {
      setCallerAudioStream(null);
      setCallerAudioSimulated(false);
      return;
    }
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    const dest = ctx.createMediaStreamDestination();
    // Ambient loop: soft filtered noise.
    const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.5;
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    noise.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 500;
    const ng = ctx.createGain();
    ng.gain.value = 0.04;
    noise.connect(lp).connect(ng).connect(dest);
    noise.start();
    // Heart-rate monitor: low beep ~72 bpm.
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = 220;
    const beep = ctx.createGain();
    beep.gain.value = 0;
    osc.connect(beep).connect(dest);
    osc.start();
    const iv = setInterval(() => {
      const t = ctx.currentTime;
      beep.gain.setValueAtTime(0, t);
      beep.gain.linearRampToValueAtTime(0.25, t + 0.02);
      beep.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    }, 830);
    setCallerAudioStream(dest.stream);
    setCallerAudioSimulated(true);
    return () => {
      clearInterval(iv);
      dest.stream.getTracks().forEach((t) => t.stop());
      void ctx.close();
    };
  }, [callActive, ownCall, stream, callerMuted]);

  const toggleCallerMute = useCallback(() => {
    setCallerMuted((m) => {
      const next = !m;
      stream?.getAudioTracks().forEach((t) => { t.enabled = !next; });
      return next;
    });
  }, [stream]);

  const selectIncident = useCallback((id: string) => {
    setSelectedId(id);
    setSelectedTicketId(null);
    setIncidents((prev) => prev.map((incident) =>
      incident.id === id && incident.isOnline ? { ...incident, operatorViewing: true } : incident,
    ));
  }, []);

  const toggleTriageTag = useCallback((tag: TriageTag) => {
    if (!callActive) return;
    setIncidents((prev) => prev.map((incident) =>
      incident.isOnline
        ? {
            ...incident,
            triageTags: incident.triageTags.includes(tag)
              ? incident.triageTags.filter((t) => t !== tag)
              : [...incident.triageTags, tag],
          }
        : incident,
    ));
  }, [callActive]);

  const toggleFlashlight = useCallback(() => {
    setFlashlightOn((on) => {
      const next = !on;
      const track = stream?.getVideoTracks()[0];
      try {
        // Torch is only available on capable mobile hardware; visual fallback otherwise.
        void track?.applyConstraints({
          advanced: [{ torch: next }],
        } as unknown as MediaTrackConstraints);
      } catch {
        /* no torch capability */
      }
      return next;
    });
  }, [stream]);

  const startRecording = useCallback(() => {
    const audioTracks = stream?.getAudioTracks() ?? [];
    if (audioTracks.length === 0 || recorderRef.current) return;
    discardClipsRef.current = false;
    const recorder = new MediaRecorder(new MediaStream(audioTracks));
    chunksRef.current = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
      if (blob.size > 0 && !discardClipsRef.current) {
        const url = URL.createObjectURL(blob);
        setVoiceClips((prev) => [{ id: crypto.randomUUID(), url, at: Date.now() }, ...prev]);
      }
      recorderRef.current = null;
      setRecording(false);
    };
    recorderRef.current = recorder;
    recorder.start();
    setRecording(true);
  }, [stream]);

  const stopRecording = useCallback(() => {
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
  }, []);

  const deleteIncident = useCallback(
    (id: string) => {
      setIncidents((prev) => prev.filter((i) => i.id !== id));
      if (isStaffRef.current) void supabase.from("incidents").delete().eq("id", id).then(() => {});
      setSelectedId((cur) => {
        if (cur !== id) return cur;
        // The viewed incident was deleted: fully reset the live diagnostic view.
        discardClipsRef.current = true;
        if (recorderRef.current && recorderRef.current.state !== "inactive") {
          recorderRef.current.stop();
        }
        recorderRef.current = null;
        setRecording(false);
        setFlashlightOn(false);
        stopTracks(stream);
        setStream(null);
        setCallActive(false);
        setPerms({ location: false, camera: false, mic: false });
        setMessage("");
        setCoords(null);
        stopVoiceBridge();
        setVoiceClips((prev) => {
          prev.forEach((clip) => URL.revokeObjectURL(clip.url));
          return [];
        });
        return null;
      });
    },
    [stopTracks, stream, stopVoiceBridge],
  );

  // Local WebRTC bridge between windows: the caller window offers its camera/mic,
  // any window without its own call answers (sending back the doctor mic if on).
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const rtcChanRef = useRef<BroadcastChannel | null>(null);
  const localMediaRef = useRef<{ own: boolean; tracks: MediaStreamTrack[]; op: MediaStream | null }>({ own: false, tracks: [], op: null });
  localMediaRef.current = {
    own: ownCall,
    tracks: [...(stream?.getVideoTracks() ?? []), ...(callerAudioStream?.getAudioTracks() ?? [])],
    op: operatorStream,
  };
  const closePc = useCallback(() => { pcRef.current?.close(); pcRef.current = null; }, []);
  const sidRef = useRef("");
  const pendingIce = useRef<RTCIceCandidateInit[]>([]);
  // Signaling fans out to the same-browser BroadcastChannel AND the per-incident
  // Realtime room `incident-<id>` so a patient phone and admin desk can connect.
  const rtRoomRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const seenSig = useRef(new Set<string>());
  const sendSig = useCallback((msg: Record<string, unknown>) => {
    const m = { ...msg, mid: crypto.randomUUID() };
    seenSig.current.add(m.mid);
    rtcChanRef.current?.postMessage(m);
    void rtRoomRef.current?.send({ type: "broadcast", event: "rtc", payload: m });
  }, []);
  const sigHandlerRef = useRef<(d: Record<string, unknown>) => void>(() => {});
  const makePc = useCallback((_ch: unknown, sid: string) => {
    closePc();
    sidRef.current = sid; pendingIce.current = [];
    const pc = new RTCPeerConnection({ iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }] });
    pcRef.current = pc;
    pc.onicecandidate = (e) => { if (e.candidate) sendSig({ type: "ice", sid, c: e.candidate.toJSON() }); };
    return pc;
  }, [closePc]);
  const sendOffer = useCallback(async () => {
    const ch = rtcChanRef.current; const m = localMediaRef.current;
    if (!ch || !m.own || m.tracks.length === 0) return;
    const sid = crypto.randomUUID();
    const pc = makePc(ch, sid);
    const ms = new MediaStream(m.tracks);
    m.tracks.forEach((t) => pc.addTrack(t, ms));
    if (!m.tracks.some((t) => t.kind === "audio")) pc.addTransceiver("audio", { direction: "recvonly" });
    pc.ontrack = (e) => setRemoteOperator(e.streams[0] ?? new MediaStream([e.track]));
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    sendSig({ type: "offer", sid, sdp: offer });
  }, [makePc, sendSig]);
  useEffect(() => {
    if (typeof BroadcastChannel === "undefined" || typeof RTCPeerConnection === "undefined") return;
    const ch = new BroadcastChannel("rescue-rapid-rtc");
    rtcChanRef.current = ch;
    const handle = async (raw: Record<string, unknown>) => {
      const mid = raw["mid"] as string | undefined;
      if (mid) { if (seenSig.current.has(mid)) return; seenSig.current.add(mid); }
      const d = raw as { type: string; sid?: string; sdp?: RTCSessionDescriptionInit; c?: RTCIceCandidateInit };
      const flush = async () => { const pc = pcRef.current; if (!pc) return; for (const c of pendingIce.current.splice(0)) await pc.addIceCandidate(c).catch(() => {}); };
      try {
        if (d.type === "hello") { await sendOffer(); }
        else if (d.type === "bye") { closePc(); setRemoteStream(null); setRemoteOperator(null); }
        else if (d.type === "offer" && d.sdp && !localMediaRef.current.own) {
          const pc = makePc(ch, d.sid ?? "");
          pc.ontrack = (ev) => setRemoteStream(ev.streams[0] ?? new MediaStream([ev.track]));
          await pc.setRemoteDescription(d.sdp);
          await flush();
          const op = localMediaRef.current.op;
          op?.getAudioTracks().forEach((t) => pc.addTrack(t, op));
          const ans = await pc.createAnswer();
          await pc.setLocalDescription(ans);
          sendSig({ type: "answer", sid: d.sid, sdp: ans });
        } else if (d.type === "answer" && d.sdp && pcRef.current && localMediaRef.current.own && d.sid === sidRef.current) {
          await pcRef.current.setRemoteDescription(d.sdp);
          await flush();
        } else if (d.type === "ice" && d.c && pcRef.current && d.sid === sidRef.current) {
          if (pcRef.current.remoteDescription) await pcRef.current.addIceCandidate(d.c);
          else pendingIce.current.push(d.c);
        }
      } catch { /* negotiation race; next offer recovers */ }
    };
    sigHandlerRef.current = (d) => void handle(d);
    ch.onmessage = (e) => void handle(e.data as Record<string, unknown>);
    sendSig({ type: "hello" });
    return () => { ch.close(); rtcChanRef.current = null; closePc(); };
  }, [sendOffer, makePc, closePc, sendSig]);
  // Per-incident Realtime room: caller joins its own incident, staff join the selected one.
  const rtRoom = ownCall ? ownIncidentRef.current : selectedId;
  useEffect(() => {
    if (!rtRoom || rtRoom.startsWith("mock-")) return;
    const room = supabase.channel(`incident-${rtRoom}`, { config: { broadcast: { self: false } } });
    room.on("broadcast", { event: "rtc" }, ({ payload }) => sigHandlerRef.current(payload as Record<string, unknown>));
    room.subscribe((status) => { if (status === "SUBSCRIBED") { rtRoomRef.current = room; sendSig({ type: "hello" }); } });
    return () => { if (rtRoomRef.current === room) rtRoomRef.current = null; void supabase.removeChannel(room); };
  }, [rtRoom, sendSig]);
  // Caller: (re)offer whenever outgoing media changes; tell peers when the call ends.
  const trackKey = localMediaRef.current.tracks.map((t) => t.id).join(",");
  useEffect(() => {
    if (ownCall && trackKey) void sendOffer();
    else if (!ownCall) { sendSig({ type: "bye" }); if (pcRef.current && localMediaRef.current.tracks.length === 0) closePc(); setRemoteOperator(null); }
  }, [ownCall, trackKey, sendOffer, closePc, sendSig]);
  // Doctor window: ask the caller to renegotiate when the doctor mic turns on/off.
  useEffect(() => {
    if (!ownCall) sendSig({ type: "hello" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [operatorStream]);
  useEffect(() => { if (!callActive) setRemoteStream(null); }, [callActive]);
  const remoteAudio = useMemo(() => {
    const a = remoteStream?.getAudioTracks() ?? [];
    return a.length ? new MediaStream(a) : null;
  }, [remoteStream]);
  const effStream = stream ?? remoteStream;
  const effCallerAudio = callerAudioStream ?? remoteAudio;
  const effOperator = operatorStream ?? remoteOperator;

  // ---- Cloud: patient pushes own SOS incident fields (throttled) ----
  const ownIncident = incidents.find((i) => i.id === ownIncidentRef.current);
  const ownTags = ownIncident?.triageTags.join(",") ?? "";
  useEffect(() => {
    const id = ownIncidentRef.current;
    if (!id || !ownCall || !tokenRef.current) return;
    const h = setTimeout(() => {
      void updateIncident({ data: {
        id, token: tokenRef.current, emergency_message: message.slice(0, 4000),
        latitude: coords?.lat ?? null, longitude: coords?.lng ?? null,
        triage_tags: (ownTags ? ownTags.split(",") : []) as TriageTag[],
      } }).catch(() => {});
    }, 400);
    return () => clearTimeout(h);
  }, [ownCall, message, coords?.lat, coords?.lng, ownTags]);
  // Patient watches own incident; if staff resolve (delete) it, end locally.
  useEffect(() => {
    if (!ownCall) return;
    const iv = setInterval(async () => {
      const id = ownIncidentRef.current;
      if (!id) return;
      try {
        const s = await getIncidentStatus({ data: { id, token: tokenRef.current } });
        if (!s.exists) setIncidents((prev) => prev.filter((i) => i.id !== id));
      } catch { /* offline */ }
    }, 4000);
    return () => clearInterval(iv);
  }, [ownCall]);
  // Patient pushes symptom selection for own active ticket.
  const activeSymptoms = clinicTickets.find((t) => t.id === activeTicketId)?.symptoms.join(",") ?? "";
  useEffect(() => {
    const id = activeTicketId;
    if (!id || !ownTicketsRef.current.has(id)) return;
    const h = setTimeout(() => {
      void updateTicket({ data: { id, token: tokenRef.current, selected_symptoms: (activeSymptoms ? activeSymptoms.split(",") : []) as ClinicSymptom[] } }).catch(() => {});
    }, 200);
    return () => clearTimeout(h);
  }, [activeTicketId, activeSymptoms]);

  type MsgRow = { id: string; ticket_id?: string; sender: string; message_text: string | null; image_url: string | null; audio_url: string | null; created_at: string };
  const ingestMessages = useCallback((ticketId: string, rows: MsgRow[]) => {
    if (!rows.length) return;
    setClinicTickets((prev) => prev.map((t) => {
      if (t.id !== ticketId) return t;
      const seen = new Set([...t.chat.map((m) => m.id), ...t.voiceClips.map((v) => v.id)]);
      const chat = [...t.chat]; const clips = [...t.voiceClips]; let changed = false;
      for (const r of rows) {
        if (seen.has(r.id)) continue;
        changed = true;
        const from = r.sender === "doctor" ? "doctor" : "patient";
        const at = new Date(r.created_at).getTime();
        if (r.audio_url) clips.push({ id: r.id, from, url: r.audio_url, at });
        if (r.message_text || r.image_url) chat.push({ id: r.id, from, text: r.message_text ?? undefined, photo: r.image_url ?? undefined, at });
      }
      return changed ? { ...t, chat, voiceClips: clips, readByDoctor: t.readByDoctor && !rows.some((r) => r.sender === "patient" && !seen.has(r.id)) } : t;
    }));
  }, []);
  // Patient polls the active consultation for doctor replies.
  useEffect(() => {
    const id = activeTicketId;
    if (!id || isStaff) return;
    let stop = false;
    const tick = async () => {
      if (!ownTicketsRef.current.has(id)) return;
      try {
        const r = await getTicketMessages({ data: { ticketId: id, token: tokenRef.current } });
        if (!stop) ingestMessages(id, r.messages as MsgRow[]);
      } catch { /* offline */ }
    };
    void tick();
    const iv = setInterval(tick, 2500);
    return () => { stop = true; clearInterval(iv); };
  }, [activeTicketId, isStaff, ingestMessages]);

  // ---- Cloud: staff session loads everything and subscribes in real time ----
  useEffect(() => {
    const check = async () => {
      try {
        if (hasTestAdminSession()) {
          // Mock login alone has no database session, so RLS would silently return 0 rows. Sign in for real.
          const { data: cur } = await supabase.auth.getUser();
          if (!cur.user) {
            const { error } = await supabase.auth.signInWithPassword({ email: "admin@rescuerapid.com", password: "rescue2026" });
            if (error) { console.error("Test staff sign-in failed", error); toast.error(`Staff DB sign-in failed: ${error.message}`); }
          }
          setIsStaff(true); return;
        }
        const { data } = await supabase.auth.getUser();
        if (!data.user) { setIsStaff(false); return; }
        const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id).eq("role", "staff").maybeSingle();
        setIsStaff(!!role);
      } catch { setIsStaff(false); }
    };
    void check();
    const { data: sub } = supabase.auth.onAuthStateChange((ev) => {
      if (ev === "SIGNED_IN" || ev === "SIGNED_OUT" || ev === "USER_UPDATED") void check();
    });
    return () => sub.subscription.unsubscribe();
  }, []);
  const selectedIdRef = useRef<string | null>(null);
  selectedIdRef.current = selectedId;
  const ownCallRef = useRef(false);
  ownCallRef.current = ownCall;
  useEffect(() => {
    if (!isStaff) return;
    type IncRow = { id: string; created_at: string; type?: string; latitude: number | null; longitude: number | null; emergency_message: string; is_online: boolean; triage_tags: string[] };
    type TicRow = { id: string; created_at: string; appointment_type?: string; selected_symptoms: string[]; is_resolved: boolean };
    const applyIncident = (r: IncRow) => {
      if (r.type && r.type !== "emergency") return; // strict: emergency queue only
      setIncidents((prev) => {
        const cur = prev.find((i) => i.id === r.id);
        const next: Incident = cur
          ? { ...cur, lat: r.latitude ?? (r as { lat?: number | null }).lat ?? null, lng: r.longitude ?? (r as { lng?: number | null }).lng ?? null, isOnline: r.is_online, triageTags: r.triage_tags as TriageTag[], operatorViewing: r.is_online && cur.operatorViewing }
          : { id: r.id, type: "emergency" as const, label: "Distress Alert / အရေးပေါ်ဖုန်း", startedAt: new Date(r.created_at).getTime(), isOnline: r.is_online, operatorViewing: false,
              triageTags: r.triage_tags as TriageTag[], deviceId: "cloud", flooding: false, bot: false, telemetryChecked: false,
              telemetry: { location: (r.latitude ?? (r as { lat?: number | null }).lat) != null, camera: false, mic: false }, lat: r.latitude ?? (r as { lat?: number | null }).lat ?? null, lng: r.longitude ?? (r as { lng?: number | null }).lng ?? null };
        return cur ? prev.map((i) => (i.id === r.id ? next : i)) : [next, ...prev];
      });
      if (selectedIdRef.current === r.id && !ownCallRef.current) {
        setMessage(r.emergency_message);
        setCoords(r.latitude != null && r.longitude != null ? { lat: r.latitude, lng: r.longitude } : null);
        setCallActive(r.is_online);
      }
    };
    const applyTicket = (r: TicRow) => {
      if (r.appointment_type && r.appointment_type !== "outpatient") return; // strict: telemedicine queue only
      setClinicTickets((prev) => {
        const cur = prev.find((t) => t.id === r.id);
        if (cur) return prev.map((t) => (t.id === r.id ? { ...t, symptoms: (r.selected_symptoms ?? []) as ClinicSymptom[], open: !r.is_resolved } : t));
        return [{ id: r.id, type: "telemedicine" as const, startedAt: new Date(r.created_at).getTime(), symptoms: r.selected_symptoms as ClinicSymptom[], description: "", advice: "",
          photos: [], voiceClips: [], chat: [], readByDoctor: false, open: !r.is_resolved, bot: false }, ...prev];
      });
    };
    let cancelled = false;
    void (async () => {
      const CACHE = "rescue-staff-cache";
      const useFallback = () => {
        let cached: { inc: IncRow[]; tic: TicRow[]; msg: MsgRow[] } | null = null;
        try { cached = JSON.parse(localStorage.getItem(CACHE) ?? "null"); } catch { /* ignore */ }
        const now = Date.now();
        const data = cached ?? {
          inc: [{ id: "mock-incident-1", created_at: new Date(now - 90_000).toISOString(), latitude: 16.8409, longitude: 96.1735,
            emergency_message: "Mock SOS: patient reports chest pain near Sule Pagoda.", is_online: true, triage_tags: ["chest"] }],
          tic: [{ id: "mock-ticket-1", created_at: new Date(now - 300_000).toISOString(), selected_symptoms: ["fever"], is_resolved: false }],
          msg: [{ id: "mock-msg-1", ticket_id: "mock-ticket-1", sender: "patient", message_text: "Mock chat: I have had a fever since yesterday.",
            image_url: null, audio_url: null, created_at: new Date(now - 280_000).toISOString() }],
        };
        if (cancelled) return;
        data.inc.slice().reverse().forEach(applyIncident);
        data.tic.slice().reverse().forEach(applyTicket);
        const g = new Map<string, MsgRow[]>();
        data.msg.forEach((r) => { if (!r.ticket_id) return; const l = g.get(r.ticket_id) ?? []; l.push(r); g.set(r.ticket_id, l); });
        g.forEach((rows, tid) => ingestMessages(tid, rows));
      };
      let res;
      try {
        res = await Promise.all([
        supabase.from("incidents").select("*").eq("type", "emergency").order("created_at", { ascending: false }).limit(100),
        supabase.from("outpatient_tickets").select("id, created_at, selected_symptoms, is_resolved").order("created_at", { ascending: false }).limit(100),
        supabase.from("chat_messages").select("id, ticket_id, sender, message_text, image_url, audio_url, created_at").order("created_at").limit(1000),
      ]);
      } catch { useFallback(); return; }
      const [inc, tic, msg] = res;
      if (inc.error || tic.error || msg.error) { useFallback(); return; }
      try { localStorage.setItem(CACHE, JSON.stringify({ inc: inc.data, tic: tic.data, msg: msg.data })); } catch { /* ignore */ }
      if (cancelled) return;
      (inc.data ?? []).slice().reverse().forEach((r) => applyIncident(r as IncRow));
      (tic.data ?? []).slice().reverse().forEach((r) => applyTicket(r as TicRow));
      const byTicket = new Map<string, MsgRow[]>();
      (msg.data ?? []).forEach((r) => { const l = byTicket.get(r.ticket_id) ?? []; l.push(r as MsgRow); byTicket.set(r.ticket_id, l); });
      byTicket.forEach((rows, tid) => ingestMessages(tid, rows));
    })();
    const ch = supabase.channel("staff-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "incidents" }, (p) => {
        if (p.eventType === "DELETE") { const id = (p.old as { id: string }).id; setIncidents((prev) => prev.filter((i) => i.id !== id)); }
        else applyIncident(p.new as IncRow);
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "outpatient_tickets" }, (p) => {
        if (p.eventType === "DELETE") { const id = (p.old as { id: string }).id; setClinicTickets((prev) => prev.filter((t) => t.id !== id)); }
        else applyTicket(p.new as TicRow);
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (p) => {
        const r = p.new as MsgRow; if (r.ticket_id) ingestMessages(r.ticket_id, [r]);
      })
      .subscribe();
    // 3s polling fallback in case realtime is throttled or blocked.
    const poll = setInterval(async () => {
      try {
        const [inc, tic] = await Promise.all([
          supabase.from("incidents").select("*").eq("type", "emergency").order("created_at", { ascending: false }).limit(100),
          supabase.from("outpatient_tickets").select("id, created_at, selected_symptoms, is_resolved").order("created_at", { ascending: false }).limit(100),
        ]);
        if (cancelled) return;
        if (!inc.error && inc.data) {
          const ids = new Set(inc.data.map((r) => r.id));
          setIncidents((prev) => prev.filter((i) => i.deviceId !== "cloud" || ids.has(i.id)));
          inc.data.slice().reverse().forEach((r) => applyIncident(r as IncRow));
          // Temporary debug toast: confirm each 3s poll result on /admin.
          toast(`Poll completed: ${inc.data.length} total emergency incidents loaded from DB`, { id: "admin-poll", position: "bottom-center", duration: 2500 });
        }
        if (inc.error) { console.error("Admin poll error", inc.error); toast.error(`Poll error: ${inc.error.message}`, { id: "admin-poll" }); }
        if (!tic.error && tic.data) tic.data.slice().reverse().forEach((r) => applyTicket(r as TicRow));
      } catch { /* offline: keep current view */ }
    }, 3000);
    return () => { cancelled = true; clearInterval(poll); void supabase.removeChannel(ch); };
  }, [isStaff, ingestMessages]);
  // When staff switch the viewed incident, show its latest cloud location/message.
  useEffect(() => {
    if (!isStaff || !selectedId || ownCall) return;
    void supabase.from("incidents").select("emergency_message, latitude, longitude, is_online").eq("id", selectedId).maybeSingle().then(({ data }) => {
      if (!data) return;
      setMessage(data.emergency_message);
      setCoords(data.latitude != null && data.longitude != null ? { lat: data.latitude, lng: data.longitude } : null);
      setCallActive(data.is_online);
    }, () => { /* offline: keep cached view */ });
  }, [isStaff, selectedId, ownCall]);

  const value = useMemo<RescueContextValue>(
    () => ({
      callActive,
      perms,
      mockCoords,
      setMockCoords,
      message,
      setMessage,
      coords,
      incidents,
      selectedId,
      selectIncident,
      toggleTriageTag,
      deleteIncident,
      stream: effStream,
      flashlightOn,
      toggleFlashlight,
      recording,
      startRecording,
      stopRecording,
      voiceClips,
      startCall,
      endCall,
      voiceBridge,
      operatorStream: effOperator,
      startVoiceBridge,
      stopVoiceBridge,
      callerMuted,
      callerAudioStream: effCallerAudio,
      callerAudioSimulated,
      toggleCallerMute,
      botBlocked,
      flagBot,
      coolingDown,
      sosStatus, sosError,
      clinicTickets, activeTicketId, selectedTicketId, startClinic, exitClinic, toggleSymptom,
      setClinicDescription, setClinicAdvice, selectTicket, deleteTicket, addClinicPhoto, addVoiceClip, addChatMessage, sessionKey,
    }),
    [
      callActive,
      perms,
      mockCoords,
      message,
      coords,
      incidents,
      selectedId,
      selectIncident,
      toggleTriageTag,
      deleteIncident,
      effStream,
      flashlightOn,
      toggleFlashlight,
      recording,
      startRecording,
      stopRecording,
      voiceClips,
      startCall,
      endCall,
      voiceBridge,
      effOperator,
      startVoiceBridge,
      stopVoiceBridge,
      callerMuted,
      effCallerAudio,
      callerAudioSimulated,
      toggleCallerMute,
      botBlocked,
      flagBot,
      coolingDown,
      sosStatus, sosError,
      clinicTickets, activeTicketId, selectedTicketId, startClinic, exitClinic, toggleSymptom,
      setClinicDescription, setClinicAdvice, selectTicket, deleteTicket, addClinicPhoto, addVoiceClip, addChatMessage, sessionKey,
    ],
  );

  return <RescueContext.Provider value={value}>{children}</RescueContext.Provider>;
}

export function useRescue() {
  const ctx = useContext(RescueContext);
  if (!ctx) throw new Error("useRescue must be used inside RescueProvider");
  return ctx;
}
