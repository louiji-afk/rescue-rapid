import { z } from "zod";

export const sosSchema = z.object({
  id: z.string().uuid(),
  token: z.string().min(20).max(100),
  sessionKey: z.string().max(20),
  type: z.literal("emergency").optional(),
  latitude: z.number().min(-90).max(90).nullable().optional(),
  longitude: z.number().min(-180).max(180).nullable().optional(),
});

// Idempotent: the direct HTTP route and the server function may both deliver the same SOS.
export async function insertSos(d: z.infer<typeof sosSchema>) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.from("incidents").upsert(
    { id: d.id, patient_token: d.token, anonymous_session_key: d.sessionKey, type: "emergency", latitude: d.latitude ?? null, longitude: d.longitude ?? null },
    { onConflict: "id", ignoreDuplicates: true },
  );
  if (error) throw new Error("Could not create alert");
}
