import { createServerFn } from "@tanstack/react-start";

// TEMPORARY demo helper: ensures the public test staff account exists. Remove before real use.
export const TEST_ADMIN_EMAIL = "admin@rescuerapid.com";

export const ensureTestAdmin = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const password = "rescue2026";
  let userId: string | undefined;
  const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
    email: TEST_ADMIN_EMAIL, password, email_confirm: true,
  });
  if (created?.user) userId = created.user.id;
  else {
    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const existing = list?.users.find((u) => u.email?.toLowerCase() === TEST_ADMIN_EMAIL);
    if (!existing) throw new Error(error?.message ?? "Could not create test admin");
    userId = existing.id;
    await supabaseAdmin.auth.admin.updateUserById(userId, { password, email_confirm: true });
  }
  await supabaseAdmin.from("user_roles").upsert({ user_id: userId, role: "staff" }, { onConflict: "user_id,role", ignoreDuplicates: true });
  return { ok: true };
});
