import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Anonymous patients never sign in. Each browser holds a private random token;
// every write/read here is checked against the token stored on the row.
const uuid = z.string().uuid();
const token = z.string().min(20).max(100);
const sessionKey = z.string().max(20);
const MAX_MEDIA = 3_000_000; // data URLs for photos / voice notes

function clean<T extends object>(o: T): { [K in keyof T]: Exclude<T[K], undefined> } {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as never;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const createIncident = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({
    id: uuid, token, sessionKey,
    type: z.literal("emergency").optional(),
    latitude: z.number().min(-90).max(90).nullable().optional(),
    longitude: z.number().min(-180).max(180).nullable().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { insertSos } = await import("./sos-insert.server");
    await insertSos(data);
    return { ok: true };
  });

export const updateIncident = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({
    id: uuid, token,
    latitude: z.number().min(-90).max(90).nullable().optional(),
    longitude: z.number().min(-180).max(180).nullable().optional(),
    emergency_message: z.string().max(4000).optional(),
    is_online: z.boolean().optional(),
    triage_tags: z.array(z.enum(["chest", "breathing", "bleeding"])).max(3).optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { id, token: t, ...patch } = data;
    const db = await admin();
    await db.from("incidents").update(clean(patch)).eq("id", id).eq("patient_token", t);
    return { ok: true };
  });

export const getIncidentStatus = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ id: uuid, token }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: row } = await db.from("incidents").select("is_online").eq("id", data.id).eq("patient_token", data.token).maybeSingle();
    return { exists: !!row, isOnline: row?.is_online ?? false };
  });

export const createTicket = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ id: uuid, token, sessionKey }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { error } = await db.from("outpatient_tickets").insert({ id: data.id, patient_token: data.token, anonymous_session_key: data.sessionKey, appointment_type: "outpatient" });
    if (error) throw new Error("Could not create consultation");
    return { ok: true };
  });

export const updateTicket = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({
    id: uuid, token,
    selected_symptoms: z.array(z.enum(["fever", "headache", "cough", "rash", "stomach", "fatigue"])).max(6).optional(),
    is_resolved: z.boolean().optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const { id, token: t, ...patch } = data;
    const db = await admin();
    await db.from("outpatient_tickets").update(clean(patch)).eq("id", id).eq("patient_token", t);
    return { ok: true };
  });

export const sendPatientMessage = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({
    id: uuid, ticketId: uuid, token,
    text: z.string().max(4000).optional(),
    image: z.string().startsWith("data:image/").max(MAX_MEDIA).optional(),
    audio: z.string().startsWith("data:audio/").max(MAX_MEDIA).optional(),
  }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: t } = await db.from("outpatient_tickets").select("id").eq("id", data.ticketId).eq("patient_token", data.token).maybeSingle();
    if (!t) throw new Error("Consultation not found");
    let audioUrl: string | null = null;
    if (data.audio) {
      const { storeVoiceNote } = await import("./voice-upload.server");
      audioUrl = await storeVoiceNote(data.audio, data.ticketId, data.id);
    }
    await db.from("chat_messages").insert({
      id: data.id, ticket_id: data.ticketId, sender: "patient",
      message_text: data.text ?? null, image_url: data.image ?? null, audio_url: audioUrl,
    });
    return { ok: true, audioUrl };
  });

// Staff voice replies: verify the caller is staff, then store in the bucket.
export const sendDoctorVoice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({
    id: uuid, ticketId: uuid,
    audio: z.string().startsWith("data:audio/").max(MAX_MEDIA),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: role } = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId).eq("role", "staff").maybeSingle();
    if (!role) throw new Error("Staff access required");
    const { storeVoiceNote } = await import("./voice-upload.server");
    const audioUrl = await storeVoiceNote(data.audio, data.ticketId, data.id);
    const { error } = await context.supabase.from("chat_messages").insert({ id: data.id, ticket_id: data.ticketId, sender: "doctor", audio_url: audioUrl });
    if (error) throw new Error(error.message);
    return { ok: true, audioUrl };
  });

export const getTicketMessages = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ ticketId: uuid, token }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: t } = await db.from("outpatient_tickets").select("id").eq("id", data.ticketId).eq("patient_token", data.token).maybeSingle();
    if (!t) return { exists: false, messages: [] };
    const { data: rows } = await db.from("chat_messages")
      .select("id, sender, message_text, image_url, audio_url, created_at")
      .eq("ticket_id", data.ticketId).order("created_at").limit(300);
    return { exists: true, messages: rows ?? [] };
  });
