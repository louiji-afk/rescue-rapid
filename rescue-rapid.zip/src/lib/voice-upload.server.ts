// Stores a recorded voice note (data URL) in the private `telemedicine_audio`
// bucket and returns a long-lived signed URL to save in chat_messages.audio_url.
export async function storeVoiceNote(dataUrl: string, ticketId: string, id: string): Promise<string> {
  const m = /^data:(audio\/[\w.+-]+)(?:;[^,]*)?;base64,(.+)$/.exec(dataUrl);
  if (!m) throw new Error("Invalid audio");
  const mime = m[1]!;
  const bytes = Uint8Array.from(atob(m[2]!), (c) => c.charCodeAt(0));
  const ext = mime.includes("mp4") ? "m4a" : mime.includes("mpeg") ? "mp3" : mime.includes("ogg") ? "ogg" : "webm";
  const path = `${ticketId}/${id}.${ext}`;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const bucket = supabaseAdmin.storage.from("telemedicine_audio");
  const { error } = await bucket.upload(path, bytes, { contentType: mime, upsert: true });
  if (error) throw new Error(`Voice upload failed: ${error.message}`);
  const { data, error: e2 } = await bucket.createSignedUrl(path, 60 * 60 * 24 * 365);
  if (e2 || !data) throw new Error("Could not create voice link");
  return data.signedUrl;
}
