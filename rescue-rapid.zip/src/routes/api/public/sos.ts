import { createFileRoute } from "@tanstack/react-router";
import { insertSos, sosSchema } from "@/lib/sos-insert.server";

// Direct HTTP SOS endpoint (anonymous patients). Only creates a new row; never reads or overwrites data.
export const Route = createFileRoute("/api/public/sos")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try { body = await request.json(); } catch { return new Response("Bad request", { status: 400 }); }
        const parsed = sosSchema.safeParse(body);
        if (!parsed.success) return new Response("Bad request", { status: 400 });
        try { await insertSos(parsed.data); } catch { return new Response("Failed", { status: 500 }); }
        return Response.json({ ok: true });
      },
    },
  },
});
