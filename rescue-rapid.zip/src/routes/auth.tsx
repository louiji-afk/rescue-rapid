import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { ensureTestAdmin, TEST_ADMIN_EMAIL } from "@/lib/test-admin.functions";
import {
  AUTH_TIMEOUT_MS,
  NETWORK_ERROR_MSG,
  setTestAdminSession,
  isTestAdminCredentials,
  withTimeout,
} from "@/lib/test-session";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Staff Sign In — Rescue Rapid" },
      { name: "description", content: "Secure sign in for Rescue Rapid medical staff." },
      { property: "og:title", content: "Staff Sign In — Rescue Rapid" },
      { property: "og:description", content: "Secure sign in for Rescue Rapid medical staff." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);

  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/admin", replace: true }); });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setError(null); setInfo(null);
    if (mode === "in" && isTestAdminCredentials(email, pw)) {
      // Local test login: no network call at all.
      setTestAdminSession();
      setBusy(false);
      navigate({ to: "/admin", replace: true });
      return;
    }
    if (mode === "in") {
      const id = email.trim();
      const loginEmail = id.toLowerCase() === "admin" ? TEST_ADMIN_EMAIL : id;
      try {
        let { error: err } = await withTimeout(
          supabase.auth.signInWithPassword({ email: loginEmail, password: pw }),
          AUTH_TIMEOUT_MS,
        );
        if (err && loginEmail === TEST_ADMIN_EMAIL && pw === "rescue2026") {
          await withTimeout(ensureTestAdmin(), AUTH_TIMEOUT_MS).catch(() => {});
          ({ error: err } = await withTimeout(
            supabase.auth.signInWithPassword({ email: loginEmail, password: pw }),
            AUTH_TIMEOUT_MS,
          ));
        }
        setBusy(false);
        if (err) { setError("Invalid Credentials / စကားဝှက် မှားယွင်းနေပါသည်"); setShakeKey((k) => k + 1); return; }
        navigate({ to: "/admin", replace: true });
      } catch {
        setBusy(false);
        setError(NETWORK_ERROR_MSG);
        setShakeKey((k) => k + 1);
      }
    } else {
      try {
        const { data, error: err } = await withTimeout(
          supabase.auth.signUp({ email: email.trim(), password: pw, options: { emailRedirectTo: window.location.origin + "/auth" } }),
          AUTH_TIMEOUT_MS,
        );
        setBusy(false);
        if (err) { setError(err.message); return; }
        if (data.session) navigate({ to: "/admin", replace: true });
        else setInfo("Check your email to confirm the account, then sign in.");
      } catch {
        setBusy(false);
        setError(NETWORK_ERROR_MSG);
        setShakeKey((k) => k + 1);
      }
    }
  };

  // Purely client-side demo bypass: no network calls, instant redirect.
  const bypass = () => {
    setError(null); setInfo(null);
    setTestAdminSession();
    navigate({ to: "/admin", replace: true });
  };

  const inputCls = "mt-1 w-full rounded-lg border border-input bg-background px-3 py-3 text-base font-semibold text-foreground outline-none focus:border-ring";
  return (
    <div className="grid min-h-screen place-items-center bg-background px-4 py-10 text-foreground">
      <form onSubmit={submit} className="w-full max-w-sm rounded-xl border border-border bg-surface p-6 shadow-lg">
        <h2 className="text-center text-xl font-black">{mode === "in" ? "Medical Admin Login" : "Create Staff Account"}</h2>
        <div key={shakeKey} className={error ? "mt-5 space-y-4 animate-shake" : "mt-5 space-y-4"}>
          <label className="block text-sm font-bold">
            {mode === "in" ? "Email or ID" : "Email"}
            <input type={mode === "in" ? "text" : "email"} required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" className={inputCls} />
          </label>
          <label className="block text-sm font-bold">
            Password / စကားဝှက်
            <div className="relative">
              <input type={showPw ? "text" : "password"} required minLength={8} value={pw} onChange={(e) => setPw(e.target.value)}
                autoComplete={mode === "in" ? "current-password" : "new-password"} className={inputCls + " pr-12"} />
              <button type="button" onClick={() => setShowPw((v) => !v)} aria-label={showPw ? "Hide password" : "Show password"}
                className="absolute right-2 top-1/2 mt-0.5 -translate-y-1/2 rounded-md p-2 hover:bg-accent">
                {showPw ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </label>
        </div>
        {error && <p role="alert" className="mt-4 rounded-md border border-rose bg-rose px-3 py-2 text-center text-sm font-bold text-rose-foreground">{error}</p>}
        {info && <p className="mt-4 rounded-md border border-border bg-background px-3 py-2 text-center text-sm font-semibold">{info}</p>}
        <Button type="submit" disabled={busy} className="mt-5 h-12 w-full font-black">
          {busy && <Loader2 className="h-5 w-5 animate-spin" />}
          {busy ? "Signing in…" : mode === "in" ? "Login" : "Create account"}
        </Button>
        {mode === "in" && (
          <Button type="button" variant="outline" disabled={busy} onClick={bypass} className="mt-3 h-11 w-full font-bold">
            Bypass / One-Click Test Login
          </Button>
        )}
        <button type="button" onClick={() => { setMode(mode === "in" ? "up" : "in"); setError(null); setInfo(null); }}
          className="mt-3 w-full text-center text-sm font-semibold text-muted-foreground hover:text-foreground">
          {mode === "in" ? "New staff member? Create an account" : "Already have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
