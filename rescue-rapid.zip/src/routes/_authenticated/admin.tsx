import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AdminDashboard } from "@/components/AdminDashboard";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { clearTestAdminSession, hasTestAdminSession } from "@/lib/test-session";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Medical Command Center — Rescue Rapid" },
      { name: "description", content: "Staff-only command center for emergency control and outpatient telemedicine." },
      { property: "og:title", content: "Medical Command Center — Rescue Rapid" },
      { property: "og:description", content: "Staff-only command center for emergency control and outpatient telemedicine." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: isStaff, isLoading } = useQuery({
    queryKey: ["is-staff", user.id],
    queryFn: async () => {
      if (hasTestAdminSession()) return true;
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "staff").maybeSingle();
      return !!data;
    },
  });
  const logout = async () => {
    await qc.cancelQueries(); qc.clear();
    clearTestAdminSession();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex w-full max-w-7xl items-center justify-end gap-3 px-4 pt-3">
        <span className="text-sm font-semibold text-muted-foreground">{user.email}</span>
        <Button type="button" variant="outline" onClick={logout} className="font-bold">Logout / ထွက်ရန်</Button>
      </div>
      {isLoading ? null : isStaff ? <AdminDashboard /> : (
        <div className="mx-auto mt-16 max-w-md rounded-xl border border-border bg-surface p-6 text-center">
          <h2 className="text-lg font-black">Staff access required</h2>
          <p className="mt-2 text-sm text-muted-foreground">This account is signed in but has not been granted medical staff access yet.</p>
        </div>
      )}
    </div>
  );
}
