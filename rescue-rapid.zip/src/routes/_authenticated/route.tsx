import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { hasTestAdminSession } from "@/lib/test-session";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    // Local demo bypass: a client-side test token grants access without a
    // network round-trip (test/demo use only, not real security).
    if (hasTestAdminSession()) {
      return { user: { id: "test-admin", email: "admin@rescuerapid.com" } };
    }
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: () => <Outlet />,
});
