import { createFileRoute } from "@tanstack/react-router";
import { UserInterface } from "@/components/UserInterface";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rescue Rapid — Emergency Response Console" },
      {
        name: "description",
        content:
          "Rescue Rapid is a bilingual emergency SOS app with live camera, voice, typing and GPS relay to a rescue command desk.",
      },
      { property: "og:title", content: "Rescue Rapid — Emergency Response Console" },
      {
        property: "og:description",
        content:
          "One-press SOS with live camera, microphone, typed message and GPS streamed to rescuers in real time.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <UserInterface />
    </div>
  );
}
