GRANT INSERT ON public.incidents TO anon;
CREATE POLICY "Public can create emergency SOS" ON public.incidents
FOR INSERT TO anon, authenticated
WITH CHECK (type = 'emergency' AND is_online = true AND length(patient_token) BETWEEN 20 AND 100 AND length(anonymous_session_key) <= 20 AND length(emergency_message) <= 2000 AND cardinality(triage_tags) = 0);