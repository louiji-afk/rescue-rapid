CREATE TYPE public.app_role AS ENUM ('staff', 'admin');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Bootstrap: the very first account that signs up becomes staff; later accounts need a grant.
CREATE OR REPLACE FUNCTION public.bootstrap_first_staff()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'staff') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'staff');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created_bootstrap_staff AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.bootstrap_first_staff();

CREATE TABLE public.incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  anonymous_session_key text NOT NULL,
  patient_token text NOT NULL,
  latitude double precision,
  longitude double precision,
  emergency_message text NOT NULL DEFAULT '',
  is_online boolean NOT NULL DEFAULT true,
  triage_tags text[] NOT NULL DEFAULT '{}'
);
GRANT SELECT, UPDATE, DELETE ON public.incidents TO authenticated;
GRANT ALL ON public.incidents TO service_role;
ALTER TABLE public.incidents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read incidents" ON public.incidents FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Staff update incidents" ON public.incidents FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Staff delete incidents" ON public.incidents FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'staff'));

CREATE TABLE public.outpatient_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  anonymous_session_key text NOT NULL,
  patient_token text NOT NULL,
  selected_symptoms text[] NOT NULL DEFAULT '{}',
  is_resolved boolean NOT NULL DEFAULT false
);
GRANT SELECT, UPDATE, DELETE ON public.outpatient_tickets TO authenticated;
GRANT ALL ON public.outpatient_tickets TO service_role;
ALTER TABLE public.outpatient_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read tickets" ON public.outpatient_tickets FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Staff update tickets" ON public.outpatient_tickets FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Staff delete tickets" ON public.outpatient_tickets FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'staff'));

CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.outpatient_tickets(id) ON DELETE CASCADE,
  sender text NOT NULL CHECK (sender IN ('patient', 'doctor')),
  message_text text,
  image_url text,
  audio_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX chat_messages_ticket_idx ON public.chat_messages (ticket_id, created_at);
GRANT SELECT, INSERT ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read messages" ON public.chat_messages FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Staff send doctor messages" ON public.chat_messages FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'staff') AND sender = 'doctor');

ALTER TABLE public.incidents REPLICA IDENTITY FULL;
ALTER TABLE public.outpatient_tickets REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.incidents;
ALTER PUBLICATION supabase_realtime ADD TABLE public.outpatient_tickets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;