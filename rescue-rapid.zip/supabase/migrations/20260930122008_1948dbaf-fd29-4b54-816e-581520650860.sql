CREATE OR REPLACE FUNCTION public.trigger_emergency_sos(
  p_id uuid, p_token text, p_session_key text,
  p_latitude double precision DEFAULT NULL, p_longitude double precision DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF p_token IS NULL OR length(p_token) < 20 OR length(p_token) > 100 THEN RAISE EXCEPTION 'invalid token'; END IF;
  IF p_session_key IS NULL OR length(p_session_key) > 20 THEN RAISE EXCEPTION 'invalid session key'; END IF;
  IF p_latitude IS NOT NULL AND (p_latitude < -90 OR p_latitude > 90) THEN RAISE EXCEPTION 'invalid latitude'; END IF;
  IF p_longitude IS NOT NULL AND (p_longitude < -180 OR p_longitude > 180) THEN RAISE EXCEPTION 'invalid longitude'; END IF;
  INSERT INTO public.incidents (id, patient_token, anonymous_session_key, type, is_online, latitude, longitude)
  VALUES (p_id, p_token, p_session_key, 'emergency', true, p_latitude, p_longitude)
  ON CONFLICT (id) DO NOTHING;
  RETURN p_id;
END $$;
REVOKE ALL ON FUNCTION public.trigger_emergency_sos(uuid, text, text, double precision, double precision) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.trigger_emergency_sos(uuid, text, text, double precision, double precision) TO anon, authenticated, service_role;