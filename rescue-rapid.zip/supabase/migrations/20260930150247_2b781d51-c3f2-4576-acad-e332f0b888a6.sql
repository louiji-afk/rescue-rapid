ALTER TABLE public.incidents ADD COLUMN IF NOT EXISTS lat double precision, ADD COLUMN IF NOT EXISTS lng double precision;
UPDATE public.incidents SET lat = latitude, lng = longitude WHERE lat IS NULL AND latitude IS NOT NULL;
CREATE OR REPLACE FUNCTION public.trigger_emergency_sos(p_id uuid, p_token text, p_session_key text, p_latitude double precision DEFAULT NULL::double precision, p_longitude double precision DEFAULT NULL::double precision)
 RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_id uuid := COALESCE(p_id, gen_random_uuid());
BEGIN
  IF p_token IS NULL OR length(p_token) < 20 OR length(p_token) > 100 THEN RAISE EXCEPTION 'invalid token'; END IF;
  IF p_latitude IS NOT NULL AND (p_latitude < -90 OR p_latitude > 90) THEN p_latitude := NULL; END IF;
  IF p_longitude IS NOT NULL AND (p_longitude < -180 OR p_longitude > 180) THEN p_longitude := NULL; END IF;
  INSERT INTO public.incidents (id, patient_token, anonymous_session_key, type, status, title, description, created_at, is_online, emergency_message, triage_tags, latitude, longitude, lat, lng)
  VALUES (v_id, p_token, left(COALESCE(p_session_key, ''), 20), 'emergency', 'active', 'Emergency SOS', 'Rapid mobile dispatch', now(), true, '', '{}', p_latitude, p_longitude, p_latitude, p_longitude)
  ON CONFLICT (id) DO NOTHING;
  RETURN v_id;
END $function$;