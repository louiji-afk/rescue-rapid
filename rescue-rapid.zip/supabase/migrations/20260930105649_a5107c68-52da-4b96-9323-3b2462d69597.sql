ALTER TABLE public.incidents ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'emergency';
ALTER TABLE public.outpatient_tickets ADD COLUMN IF NOT EXISTS appointment_type text NOT NULL DEFAULT 'outpatient';
UPDATE public.incidents SET type = 'emergency' WHERE type IS NULL OR type = '';
UPDATE public.outpatient_tickets SET appointment_type = 'outpatient' WHERE appointment_type IS NULL OR appointment_type = '';